from datetime import datetime
from typing import List
import digital_frontdoor.schemas as schemas

# Initial welcome message for new sessions
INITIAL_WELCOME_MESSAGE = """Hi there! I'm your Cleveland Clinic Virtual Triage Nurse. 
I'll help you figure out what's going on with your cold and flu symptoms and guide you toward the care that's right for you.

We'll go one step at a time to make sure you get safe, timely advice."""

FOLLOWUP_MESSAGE = """Most people can treat flu symptoms at home and start feeling better in a few days to a week.

But flu can sometimes cause more serious illness, so it's important to keep an eye on how you're feeling. 
Here are some signs that mean you to should get medical care right away.
"""

# Call 911 symptoms from protocol
CALL_911_SYMPTOMS = [
    "It feels like a life-threatening emergency",
    "Trouble breathing or very short of breath",
    "Chest pain",
    "Sudden confusion or not thinking clearly",
]

# Go to ER symptoms from protocol
GO_TO_ER_SYMPTOMS = [
    "Fever over 104°F (40°C)",
    "Fever lasting more than 5 days",
    "Fever with neck pain",
    "Low blood pressure or very fast heart rate",
    "Trouble peeing or peeing very little",
    "Severe throat pain that makes you unable to swallow",
    "A serious health condition that's getting worse (like heart failure, asthma, COPD or diabetes that's not well managed right now)",
    "Weakness or numbness in your arms or legs",
    "Fever and a weak immune system (like from chemotherapy for cancer treatment)",
]

# Call 911 immediate response
CALL_911_RESPONSE = """**You need emergency medical care.**

Based on your symptoms, it's safest to call 911 or go to the nearest emergency room right away.

**Please don't wait — get care now.**"""

# Go to ER response
GO_TO_ER_RESPONSE = """**You should go to the emergency room.**

Your symptoms suggest you need medical care as soon as possible. Please head to the nearest ER.

[Click here](https://my.clevelandclinic.org/patients/information/access/emergency-departments) for a list of Cleveland Clinic Emergency Departments.

**Don't wait - these symptoms can get worse quickly.**"""


def create_initial_messages(message_ids: List[str]) -> List[schemas.TextMessage]:
    """Create the initial greeting messages with provided UUIDs"""
    timestamp = datetime.now().isoformat()

    return [
        schemas.TextMessage(
            id=message_ids[0],
            timestamp=timestamp,
            sender="assistant",
            type="text",
            content=INITIAL_WELCOME_MESSAGE,
        ),
        schemas.TextMessage(
            id=message_ids[1],
            timestamp=timestamp,
            sender="assistant",
            type="text",
            content=FOLLOWUP_MESSAGE,
        ),
    ]


def create_call_911_multiselect(message_id: str) -> schemas.MultiSelectMessage:
    """Create the Call 911 multi-select question with provided UUID"""
    options = []

    # Add regular symptoms
    for i, symptom in enumerate(CALL_911_SYMPTOMS):
        options.append(
            schemas.MultiSelectOption(
                id=f"call911_{i}",
                text=symptom,
                value=symptom,
                selected=False,
                exclusive=False,
            )
        )

    # Add exclusive "None of the above" option
    options.append(
        schemas.MultiSelectOption(
            id="call911_none",
            text="None of the above",
            value="none",
            selected=False,
            exclusive=True,
        )
    )

    return schemas.MultiSelectMessage(
        id=message_id,
        timestamp=datetime.now().isoformat(),
        sender="assistant",
        type="multiselect",
        question="Are you having any of these emergency symptoms right now?",
        options=options,
        minSelections=1,
        maxSelections=len(options),
    )


def create_go_to_er_multiselect(message_id: str) -> schemas.MultiSelectMessage:
    """Create the Go to ER multi-select question with provided UUID"""
    options = []

    # Add regular symptoms
    for i, symptom in enumerate(GO_TO_ER_SYMPTOMS):
        options.append(
            schemas.MultiSelectOption(
                id=f"er_{i}",
                text=symptom,
                value=symptom,
                selected=False,
                exclusive=False,
            )
        )

    # Add exclusive "None of the above" option
    options.append(
        schemas.MultiSelectOption(
            id="er_none",
            text="None of the above",
            value="none",
            selected=False,
            exclusive=True,
        )
    )

    return schemas.MultiSelectMessage(
        id=message_id,
        timestamp=datetime.now().isoformat(),
        sender="assistant",
        type="multiselect",
        question="Are you having any of these symptoms?",
        options=options,
        minSelections=1,
        maxSelections=len(options),
    )


def create_call_911_recommendation(message_id: str) -> schemas.TextMessage:
    """Create Call 911 recommendation message"""
    return schemas.TextMessage(
        id=message_id,
        timestamp=datetime.now().isoformat(),
        sender="assistant",
        type="text",
        content=CALL_911_RESPONSE,
        terminateSession=True,
        urgent=True,
    )


def create_call_911_text_question(message_id: str) -> schemas.TextMessage:
    """Create the Call 911 question as a text message for simulation mode"""
    # Create a formatted text version of the symptoms list with proper line breaks
    symptoms_list = []
    for symptom in CALL_911_SYMPTOMS:
        symptoms_list.append(f"- {symptom}")

    symptoms_text = "\n".join(symptoms_list)

    question_text = f"""Do any of these emergency symptoms apply to you right now?

{symptoms_text}

Please respond with the specific symptoms you're experiencing, or "None of the above" if none apply."""

    return schemas.TextMessage(
        id=message_id,
        timestamp=datetime.now().isoformat(),
        sender="assistant",
        type="text",
        content=question_text,
    )


def create_er_recommendation(message_id: str) -> schemas.TextMessage:
    """Create Go to ER recommendation message"""
    return schemas.TextMessage(
        id=message_id,
        timestamp=datetime.now().isoformat(),
        sender="assistant",
        type="text",
        content=GO_TO_ER_RESPONSE,
        terminateSession=True,
        urgent=True,
    )
