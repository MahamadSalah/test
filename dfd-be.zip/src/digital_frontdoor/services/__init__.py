from digital_frontdoor.services.database import (
    DatabaseService,
    MySQLDatabaseService,
    PostgreSQLDatabaseService,
)
from digital_frontdoor.services.prompts import (
    PromptFactory,
    PromptFactoryImpl,
)
from digital_frontdoor.services.orchestrator import (
    OrchestratorService,
    OrchestratorServiceImpl,
)
from digital_frontdoor.services.agent import (
    AgentService,
    AgentServiceImpl,
    AgentPanel,
)

from digital_frontdoor.services.embedding import (
    EmbeddingProvider,
    OpenAIEmbeddings,
    AzureOpenAIEmbedding,
)

from digital_frontdoor.config import get_config

from typing import Literal


config = get_config()


def get_database_service() -> DatabaseService:
    # Use PostgreSQL if USE_POSTGRESQL is True, otherwise fallback to MySQL
    if config.get("USE_POSTGRESQL"):
        return PostgreSQLDatabaseService()
    else:
        return MySQLDatabaseService()


def get_prompt_factory() -> PromptFactory:
    return PromptFactoryImpl()


def get_agent_service(agent_experience: Literal["default", "panel"]) -> AgentService:
    if agent_experience == "default":
        return AgentServiceImpl()
    elif agent_experience == "panel":
        return AgentPanel()
    else:
        raise ValueError(f"Unknown agent experience type: {agent_experience}")


def get_orchestrator_service(
    agent_experience: Literal["default", "panel"],
) -> OrchestratorService:
    prompt_factory = get_prompt_factory()
    agent_service = get_agent_service(agent_experience)
    return OrchestratorServiceImpl(
        prompt_factory=prompt_factory, agent_service=agent_service
    )


def get_embedding_service() -> EmbeddingProvider:
    return AzureOpenAIEmbedding()
