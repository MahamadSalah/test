from abc import ABC, abstractmethod
from typing import List, Dict, Tuple
from digital_frontdoor.config import get_config
from sqlalchemy.ext.asyncio import AsyncSession
import logging
import tiktoken
import json
import uuid
import os
from agents.mcp import MCPServerStreamableHttp, create_static_tool_filter

from digital_frontdoor.services.prompts import PromptFactory
from digital_frontdoor.services.agent import AgentService
import digital_frontdoor.schemas as schemas
from digital_frontdoor.services.crud import (
    create_full_conversation_history_async,
    terminate_session_async,
    create_or_update_token_usage_async,
    create_or_update_token_usage_detail_async,
)

config = get_config()
logger = logging.getLogger(__name__)


class OrchestratorService(ABC):
    @abstractmethod
    async def answer(
        self,
        db: AsyncSession,
        messages: List[schemas.Message],
        session_id: str,
        orchestrator_model: str,
        guardrail_model: str,
        prompts: schemas.PromptSettings,
    ) -> Tuple[str, str]:
        pass


class OrchestratorServiceImpl(OrchestratorService):
    def __init__(self, prompt_factory: PromptFactory, agent_service: AgentService):
        self.prompt_factory = prompt_factory
        self.agent_service = agent_service

    async def record_token_usage(
        self,
        db: AsyncSession,
        session_id: str,
        guardrail_model: str,
        orchestrator_model: str,
        guardrail_token_usage: dict,
        orchestrator_token_usage: dict = None,
    ):
        """
        Record token usage for both guardrail and orchestrator agents.

        Args:
            db: Database session
            session_id: Session ID
            guardrail_model: Guardrail model name
            orchestrator_model: Orchestrator model name
            guardrail_token_usage: Token usage data from guardrail agent
            orchestrator_token_usage: Token usage data from orchestrator agent (None if not run)
        """
        try:
            # Record guardrail agent usage detail
            await create_or_update_token_usage_detail_async(
                db=db,
                session_id=session_id,
                agent_type="guardrail",
                model_name=guardrail_model,
                input_tokens=guardrail_token_usage["input_tokens"],
                cached_tokens=guardrail_token_usage["cached_tokens"],
                output_tokens=guardrail_token_usage["output_tokens"],
                reasoning_tokens=guardrail_token_usage["reasoning_tokens"],
                requests=guardrail_token_usage["requests"],
            )

            # Record orchestrator agent usage detail (zeros if not run)
            if orchestrator_token_usage is None:
                orchestrator_token_usage = {
                    "input_tokens": 0,
                    "cached_tokens": 0,
                    "output_tokens": 0,
                    "reasoning_tokens": 0,
                    "requests": 0,
                }

            await create_or_update_token_usage_detail_async(
                db=db,
                session_id=session_id,
                agent_type="orchestrator",
                model_name=orchestrator_model,
                input_tokens=orchestrator_token_usage["input_tokens"],
                cached_tokens=orchestrator_token_usage["cached_tokens"],
                output_tokens=orchestrator_token_usage["output_tokens"],
                reasoning_tokens=orchestrator_token_usage["reasoning_tokens"],
                requests=orchestrator_token_usage["requests"],
            )

            # Aggregate token usage for session totals
            total_input_tokens = (
                guardrail_token_usage["input_tokens"]
                + orchestrator_token_usage["input_tokens"]
            )
            total_cached_tokens = (
                guardrail_token_usage["cached_tokens"]
                + orchestrator_token_usage["cached_tokens"]
            )
            total_output_tokens = (
                guardrail_token_usage["output_tokens"]
                + orchestrator_token_usage["output_tokens"]
            )
            total_reasoning_tokens = (
                guardrail_token_usage["reasoning_tokens"]
                + orchestrator_token_usage["reasoning_tokens"]
            )
            total_requests = (
                guardrail_token_usage["requests"] + orchestrator_token_usage["requests"]
            )

            # Store aggregated token usage in session total
            await create_or_update_token_usage_async(
                db=db,
                session_id=session_id,
                input_tokens=total_input_tokens,
                cached_tokens=total_cached_tokens,
                output_tokens=total_output_tokens,
                reasoning_tokens=total_reasoning_tokens,
                requests=total_requests,
            )

        except Exception as e:
            logger.error(
                f"Failed to store token usage for session {session_id}: {str(e)}",
                exc_info=True,
            )

    def trim_text(
        self,
        text: str,
        model_name: str,
        max_tokens: int,
    ):

        if model_name in tiktoken.model.MODEL_TO_ENCODING:
            encoding = tiktoken.encoding_for_model(model_name)
        else:
            encoding = tiktoken.encoding_for_model("gpt-4o")

        tokenized_text = encoding.encode(text)
        return encoding.decode(tokenized_text[:max_tokens])

    def get_token_count(self, model_name: str, text: str) -> int:
        # Check if it's a single Document object and get its content
        if not text:
            return 0

        if model_name in tiktoken.model.MODEL_TO_ENCODING:
            encoding = tiktoken.encoding_for_model(model_name)
        else:
            encoding = tiktoken.encoding_for_model("gpt-4o")
        response = encoding.encode(text)
        return len(response)

    def get_chat_history(
        self,
        messages_list: List[schemas.Message],
        model_name: str,
        threshold: int,
    ) -> List[Dict[str, str]]:
        # Build unified conversation history starting with questionnaire data (oldest)
        conversations = []
        # Add chat messages (newer than questionnaire)
        for message in messages_list:
            conversations.append(json.loads(message.content))

        # Now apply token limit to the unified conversation, keeping most recent messages
        # Reverse the conversation to start from the most recent
        reversed_conversation = conversations[::-1]

        # Keep messages that fit within token threshold
        final_conversation = []
        tokens_so_far = 0

        for msg in reversed_conversation:
            # Calculate token count for this message
            token_count = self.get_token_count(model_name, json.dumps(msg))

            # Check if we can include this message within the threshold
            if tokens_so_far + token_count <= threshold:
                # Insert at beginning to maintain chronological order
                final_conversation.insert(0, msg)
                tokens_so_far += token_count
            else:
                break

        return final_conversation

    async def setup_orchestration(self, db: AsyncSession, messages, model):
        """
        Setup the initial state for orchestration.
        """
        chat_conversations = self.get_chat_history(
            messages,
            model_name=model,
            threshold=config.get("ORCHESTRATOR_CHAT_TOKENS", 1024),
        )

        return chat_conversations

    async def process_orchestration(
        self,
        db: AsyncSession,
        session_id: str,
        orchestrator_model: str,
        guardrail_model: str,
        prompts: schemas.PromptSettings,
        conversation_list: List[dict],
    ) -> str:

        guardrail_result, guardrail_token_usage = (
            await self.agent_service.run_input_guardrail_agent(
                guardrail_model, conversation_list, prompts.inputGuardrail
            )
        )

        # Terminate session if tripwire is triggered
        if guardrail_result.tripwire_triggered:
            # Still record token usage even if tripwire is triggered (orchestrator not run)
            await self.record_token_usage(
                db=db,
                session_id=session_id,
                guardrail_model=guardrail_model,
                orchestrator_model=orchestrator_model,
                guardrail_token_usage=guardrail_token_usage,
                orchestrator_token_usage=None,  # Not run due to tripwire
            )

            try:
                await terminate_session_async(db, session_id)
            except Exception as e:
                logger.error(
                    f"Failed to terminate session {session_id}: {str(e)}", exc_info=True
                )

            return "I'm sorry, I can only assist with virtual triaging.", None

        try:
            runner, trace_url, orchestrator_token_usage = (
                await self.agent_service.run_orchestrator_with_trace(
                    orchestrator_model=orchestrator_model,
                    prompts=prompts,
                    conversation_list=conversation_list,
                )
            )

            # Process all new_items to extract raw items for persistence
            raw_items = []
            for item in runner.new_items:
                # Convert raw_item to dict if it has model_dump method (Pydantic models)
                raw_item_data = item.raw_item
                if hasattr(raw_item_data, "model_dump"):
                    raw_item_data = raw_item_data.model_dump()
                elif hasattr(raw_item_data, "__dict__"):
                    # Convert object to dict for serialization
                    raw_item_data = raw_item_data.__dict__

                raw_items.append(
                    {
                        "item_type": item.__class__.__name__,
                        "raw_item": raw_item_data,
                    }
                )

            # Filter out only the last MessageOutputItem before persistence (will be handled in main.py)
            # All intermediate MessageOutputItems should be persisted to capture the full conversation
            conversations_to_persist = []

            # Find the index of the last MessageOutputItem
            last_message_output_index = -1
            for i in range(len(raw_items) - 1, -1, -1):
                if raw_items[i]["item_type"] == "MessageOutputItem":
                    last_message_output_index = i
                    break

            for i, raw_item_data in enumerate(raw_items):
                # Skip only the very last MessageOutputItem - it will be persisted by main.py with proper UUID
                # All other MessageOutputItems (intermediate ones) should be persisted
                if (
                    raw_item_data["item_type"] == "MessageOutputItem"
                    and i == last_message_output_index
                ):
                    continue

                conversations_to_persist.append(
                    {
                        "type": "raw_item",
                        "item_type": raw_item_data["item_type"],
                        "raw_item": raw_item_data["raw_item"],
                    }
                )

            await create_full_conversation_history_async(
                db=db,
                session_id=session_id,
                conversations=conversations_to_persist,
                model_name=orchestrator_model,
                tracing_url=trace_url,
            )

            # Store detailed token usage for each agent invocation
            await self.record_token_usage(
                db=db,
                session_id=session_id,
                guardrail_model=guardrail_model,
                orchestrator_model=orchestrator_model,
                guardrail_token_usage=guardrail_token_usage,
                orchestrator_token_usage=orchestrator_token_usage,
            )

            # Get the final output content and handle session termination
            final_output = runner.final_output
            if final_output:
                # Check if final_output is a Pydantic model or plain string
                if hasattr(final_output, "model_dump"):
                    # It's a Pydantic model (AssistantMessage)
                    response_dict = final_output.model_dump(exclude_none=True)

                    if response_dict.get("terminateSession", False):
                        await terminate_session_async(db, session_id)

                    # Return just the message content - main.py will handle UUID and persistence
                    content = response_dict.get("content")
                    if content is None:
                        raise ValueError(
                            f"AssistantMessage response missing 'content' field: {response_dict}"
                        )
                    return content, trace_url
                else:
                    # It's a plain string
                    return str(final_output), trace_url

            raise ValueError(
                "Orchestrator runner returned no final_output - this should not happen"
            )

        except Exception as e:
            logger.error(f"Error in process_orchestration: {str(e)}", exc_info=True)
            raise e

    async def answer(
        self,
        db: AsyncSession,
        messages: List[schemas.Message],
        session_id: str,
        orchestrator_model: str,
        guardrail_model: str,
        prompts: schemas.PromptSettings,
    ) -> Tuple[str, str]:
        """
        Orchestrates the answer generation process.
        """
        if not prompts:
            (
                orchestrator_prompt,
                input_guardrail_prompt,
            ) = self.prompt_factory.get_cold_and_flu_prompts()

            prompts = schemas.PromptSettings(
                inputGuardrail=input_guardrail_prompt,
                orchestrator=orchestrator_prompt,
            )

        try:
            # The purpose of setup_orchestration is really just to limit the context tokens
            # to prevent errors due to too many tokens
            conversation_list = await self.setup_orchestration(
                db, messages, orchestrator_model
            )

            content, trace_url = await self.process_orchestration(
                db=db,
                session_id=session_id,
                orchestrator_model=orchestrator_model,
                guardrail_model=guardrail_model,
                prompts=prompts,
                conversation_list=conversation_list,
            )

            return content, trace_url

        except Exception as e:
            logger.error(f"Error generating answer: {e}", exc_info=True)
            raise e
