from dotenv import load_dotenv, find_dotenv

load_dotenv(find_dotenv())

import mlflow

mlflow.openai.autolog()

from tenacity import (
    retry,
    stop_after_attempt,
    wait_random_exponential,
)
import asyncio
from abc import ABC, abstractmethod
from typing import List, Dict
from digital_frontdoor.config import get_config, get_credential
import json
import uuid
import logging
import os
import digital_frontdoor.schemas as schemas
from agents import (
    Agent,
    Runner,
    trace,
    gen_trace_id,
    handoff,
    RunConfig,
    InputGuardrail,
    GuardrailFunctionOutput,
    OutputGuardrailTripwireTriggered,
    InputGuardrailTripwireTriggered,
    input_guardrail,
    set_tracing_export_api_key,
    enable_verbose_stdout_logging,
    OpenAIChatCompletionsModel,
    set_default_openai_client,
    set_default_openai_api,
    function_tool,
    set_trace_processors,
)
from agents.mcp import MCPServerStreamableHttp, create_static_tool_filter
from agents.extensions import handoff_filters
from openai import AsyncAzureOpenAI
from openai.types.shared import Reasoning
from azure.identity import get_bearer_token_provider

from openai.types.responses import ResponseTextDeltaEvent

from agents.model_settings import ModelSettings

from digital_frontdoor.services import PromptFactory


config = get_config()

token_provider = get_bearer_token_provider(
    get_credential(), "https://cognitiveservices.azure.com/.default"
)

set_default_openai_client(
    AsyncAzureOpenAI(
        api_version=config.get("AZURE_API_VERSION", "2024-12-01-preview"),
        azure_endpoint=config.get("AZURE_API_BASE", ""),
        azure_ad_token_provider=token_provider,
    )
)
set_default_openai_api("chat_completions")

logger = logging.getLogger(__name__)


class AgentService(ABC):
    @abstractmethod
    async def run_input_guardrail_agent(
        self,
        model,
        input_data,
        prompt,
    ):
        pass

    @abstractmethod
    async def run_orchestrator_with_trace(
        self,
        orchestrator_model,
        prompts,
        conversation_list,
    ):
        pass


class AgentServiceImpl(AgentService):
    @retry(wait=wait_random_exponential(min=1, max=30), stop=stop_after_attempt(3))
    async def run_input_guardrail_agent(
        self,
        model,
        input_data,
        prompt,
    ):

        model_settings = (
            ModelSettings(
                temperature=config.get("GUARDRAIL_TEMPERATURE", 0.1),
            )
            if "gpt-5" not in model
            else ModelSettings()
        )

        self.guardrail_agent = Agent(
            name="Guardrail Agent",
            instructions=prompt,
            output_type=schemas.GuardrailOutput,
            model=model,
            model_settings=model_settings,
        )

        result = await Runner.run(self.guardrail_agent, input_data)
        final_output = result.final_output_as(schemas.GuardrailOutput)
        tripwire_triggered = not final_output.is_within_scope

        # Extract token usage information safely
        usage = getattr(result.context_wrapper, "usage", None)
        token_usage = (
            {
                "input_tokens": getattr(usage, "input_tokens", 0),
                "cached_tokens": getattr(
                    getattr(usage, "input_tokens_details", None), "cached_tokens", 0
                ),
                "output_tokens": getattr(usage, "output_tokens", 0),
                "reasoning_tokens": getattr(
                    getattr(usage, "output_tokens_details", None), "reasoning_tokens", 0
                ),
                "requests": getattr(usage, "requests", 1),
            }
            if usage
            else {
                "input_tokens": 0,
                "cached_tokens": 0,
                "output_tokens": 0,
                "reasoning_tokens": 0,
                "requests": 1,
            }
        )

        return (
            GuardrailFunctionOutput(
                output_info=final_output,
                tripwire_triggered=tripwire_triggered,
            ),
            token_usage,
        )

    @retry(wait=wait_random_exponential(min=1, max=30), stop=stop_after_attempt(3))
    async def run_orchestrator(
        self,
        orchestrator_model,
        prompts,
        conversation_list,
    ):

        orchestrator = Agent(
            name="Orchestrator Agent",
            instructions=prompts.orchestrator,
            model_settings=ModelSettings(
                temperature=config.get("ORCHESTRATOR_TEMPERATURE", 0.1),
            ),
            model=orchestrator_model,
            output_type=schemas.AssistantMessageWithTermination,
        )

        result = await Runner.run(orchestrator, conversation_list)

        # Extract token usage information safely
        usage = getattr(result.context_wrapper, "usage", None)
        token_usage = (
            {
                "input_tokens": getattr(usage, "input_tokens", 0),
                "cached_tokens": getattr(
                    getattr(usage, "input_tokens_details", None), "cached_tokens", 0
                ),
                "output_tokens": getattr(usage, "output_tokens", 0),
                "reasoning_tokens": getattr(
                    getattr(usage, "output_tokens_details", None), "reasoning_tokens", 0
                ),
                "requests": getattr(usage, "requests", 1),
            }
            if usage
            else {
                "input_tokens": 0,
                "cached_tokens": 0,
                "output_tokens": 0,
                "reasoning_tokens": 0,
                "requests": 1,
            }
        )

        return result, token_usage

    async def run_orchestrator_with_trace(
        self,
        orchestrator_model,
        prompts,
        conversation_list,
    ):
        """
        Run orchestrator with trace context management.
        Returns tuple of (runner_result, trace_id) for external use.
        """
        DATABRICKS_HOST = os.environ.get("DATABRICKS_HOST")
        EXP_ID = os.environ.get("MLFLOW_EXPERIMENT_ID")

        with mlflow.start_span(name="Main Trace", span_type="AGENT") as span:
            span.set_inputs(
                {
                    "orchestrator_model": orchestrator_model,
                    "prompts": prompts,
                    "conversation_list": conversation_list,
                }
            )
            runner_result, token_usage = await self.run_orchestrator(
                orchestrator_model=orchestrator_model,
                prompts=prompts,
                conversation_list=conversation_list,
            )
            span.set_outputs({"output": runner_result.final_output})

            trace_url = f"{DATABRICKS_HOST}/ml/experiments/{EXP_ID}/traces?o=8327051358258325&selectedEvaluationId={span.request_id}"
        return runner_result, trace_url, token_usage


class AgentPanel(AgentServiceImpl):
    @retry(wait=wait_random_exponential(min=1, max=30), stop=stop_after_attempt(3))
    async def run_orchestrator(
        self,
        orchestrator_model,
        prompts,
        conversation_list,
    ):
        @function_tool
        async def run_fever_expert(
            agent_input: schemas.AgentInput,
        ) -> schemas.AgentOutput:
            """
            Expert for triaging fever symptoms according to Cleveland Clinic Cold and Flu protocol.

            WHEN TO CALL: Patient reports fever, high temperature, feeling hot, chills, temperature readings, or fever-related concerns.

            INPUT SCHEMA (schemas.AgentInput):
            - patient_profile: Dict with demographics, medical history, current condition, etc.
            - patient_responses: List[PatientResponse] with question/answer pairs from conversation
            - symptoms: List[str] of reported symptoms like ["fever", "chills", "high temperature"]
            - consultation_request: Optional list of other experts who requested this consultation

            OUTPUT SCHEMA (schemas.AgentOutput):
            - case_relevance: {is_relevant: bool, reasoning: str} - whether this expert should handle the case
            - followup_questions: Optional {questions: List[str], reasoning: str} - questions to ask patient
            - final_disposition: Optional {disposition: str, reasoning: str} - final triage decision (ER, UC, EC, etc.)
            - expert_consultation: Optional - if other experts need to be consulted
            """

            prompt = """ - You are a virtual triage nurse working at Cleveland Clinic, using Cleveland Clinic proprietary medical triaging protocols.
- Your scope is currently limited to cold and flu medical triaging.
- You are an expert in triaging fever symptoms specifically.
- You follow the specific triaging protocols provided below exactly.

```
Fever Triage Protocol:
- ASK (if not already answered): "Do you have a fever over 104°F (40°C)?"
    - If yes: route to ER immediately.
    - If no: continue with other questions.

- ASK (if not already answered): "How long has your fever lasted?"
    - If more than 5 days:
        - ASK: "Have you taken your temperature with a thermometer?"
            - If yes: ASK "Has it been consistently above 100.4°F (38°C) even when it improves temporarily with medicine?"
                - If yes: route to ER immediately.
                - If no: route to urgent care.
            - If no: ASK "Do you feel warm or have chills?"
                - If yes: route to ER immediately.
                - If no: route to urgent care.
    - If 3-5 days: route to urgent care.
    - If less than 3 days: continue with other questions.

- ASK (if not already answered): "Do you have a weak immune system?"
    - ASK: "Are you actively being treated for cancer? Are you an IV drug user? Are you on immunosuppressive medications?"
        - If yes to any: route to ER immediately.
        - If no to all: continue with standard fever protocol.

- If none of the above conditions apply: route to urgent/express care.
```

- Stick to the protocol material. Do not deviate or add additional conditions not specified in the protocol.
"""
            expert = Agent(
                name="Fever Expert",
                instructions=prompt,
                model_settings=ModelSettings(
                    temperature=0,
                ),
                model="gpt-4o",
                output_type=schemas.AgentOutput,
            )

            agent_input_json = agent_input.model_dump_json(indent=2)
            result = await Runner.run(expert, agent_input_json)
            final_output = result.final_output_as(schemas.AgentOutput)
            return final_output

        @function_tool
        async def run_headache_expert(
            agent_input: schemas.AgentInput,
        ) -> schemas.AgentOutput:
            """
            Expert for triaging headache symptoms according to Cleveland Clinic Cold and Flu protocol.

            WHEN TO CALL: Patient reports headache, head pain, migraine, pain in head/skull area.

            INPUT SCHEMA (schemas.AgentInput):
            - patient_profile: Dict with demographics, medical history, current condition, etc.
            - patient_responses: List[PatientResponse] with question/answer pairs from conversation
            - symptoms: List[str] of reported symptoms like ["headache", "head pain", "migraine"]
            - consultation_request: Optional list of other experts who requested this consultation

            OUTPUT SCHEMA (schemas.AgentOutput):
            - case_relevance: {is_relevant: bool, reasoning: str} - whether this expert should handle the case
            - followup_questions: Optional {questions: List[str], reasoning: str} - questions to ask patient
            - final_disposition: Optional {disposition: str, reasoning: str} - final triage decision (ER, UC, EC, etc.)
            - expert_consultation: Optional - if other experts need to be consulted
            """

            prompt = """ - You are a virtual triage nurse working at Cleveland Clinic, using Cleveland Clinic proprietary medical triaging protocols.
- Your scope is currently limited to cold and flu medical triaging.
- You are an expert in triaging headache symptoms specifically.
- You follow the specific triaging protocols provided below exactly.

```
Headache Triage Protocol:
- ASK (if not already answered): "Do you have any pain in the back of your neck along with your headache?"
    - If yes: ASK "Are you unable to move your neck without severe pain?"
        - If yes: route to ER immediately.
        - If no: continue triaging other headache symptoms and route to urgent care if nothing more severe is found.
    - If no: continue with other questions.

- ASK (if not already answered): "Are you experiencing any confusion along with your headache?"
    - If yes: route to ER immediately.
    - If no: continue with other questions.

- ASK (if not already answered): "Do you have a high fever (over 101°F/38.3°C) that improves with medicine?"
    - If yes: your own disposition should be urgent/express care but we should consult fever expert for fever-related triaging.
    - If no: continue with other questions.

- If none of the above conditions apply: route to express care (physical) or express care virtual visit.
```

- Stick to the protocol material. Do not deviate or add additional conditions not specified in the protocol.
"""
            expert = Agent(
                name="Headache Expert",
                instructions=prompt,
                model_settings=ModelSettings(
                    temperature=0,
                ),
                model="gpt-4o",
                output_type=schemas.AgentOutput,
            )

            agent_input_json = agent_input.model_dump_json(indent=2)
            result = await Runner.run(expert, agent_input_json)
            final_output = result.final_output_as(schemas.AgentOutput)
            return final_output

        @function_tool
        async def run_sore_throat_expert(
            agent_input: schemas.AgentInput,
        ) -> schemas.AgentOutput:
            """
            Expert for triaging sore throat symptoms according to Cleveland Clinic Cold and Flu protocol.

            WHEN TO CALL: Patient reports sore throat, throat pain, difficulty swallowing, throat discomfort, throat irritation.

            INPUT SCHEMA (schemas.AgentInput):
            - patient_profile: Dict with demographics, medical history, current condition, etc.
            - patient_responses: List[PatientResponse] with question/answer pairs from conversation
            - symptoms: List[str] of reported symptoms like ["sore throat", "throat pain", "swallowing difficulty"]
            - consultation_request: Optional list of other experts who requested this consultation

            OUTPUT SCHEMA (schemas.AgentOutput):
            - case_relevance: {is_relevant: bool, reasoning: str} - whether this expert should handle the case
            - followup_questions: Optional {questions: List[str], reasoning: str} - questions to ask patient
            - final_disposition: Optional {disposition: str, reasoning: str} - final triage decision (ER, UC, EC, etc.)
            - expert_consultation: Optional - if other experts need to be consulted
            """

            prompt = """ - You are a virtual triage nurse working at Cleveland Clinic, using Cleveland Clinic proprietary medical triaging protocols.
- Your scope is currently limited to cold and flu medical triaging.
- You are an expert in triaging sore throat symptoms specifically.
- You follow the specific triaging protocols provided below exactly.

```
Sore Throat Triage Protocol:
- ASK (if not already answered): "Are you having trouble swallowing?"
    - If yes: ASK "Are you actually unable to swallow your saliva without severe pain?"
        - If yes: route to ER immediately.
        - If no: route to urgent care.
    - If no: continue with other questions.

- ASK (if not already answered): "Are you having trouble breathing?"
    - If yes: route to ER immediately.
    - If no: continue with other questions.

- ASK (if not already answered): "Do you have swelling, pain, or fever in your throat but you're still able to swallow and breathe?"
    - If yes: your own disposition should be urgent/express care but we should consult fever expert for fever-related triaging.
    - If no: continue with other questions.

- If none of the above conditions apply: route to express care (physical) or express care virtual visit.

Note: Severe throat pain with inability to swallow is a serious condition that may indicate epiglottitis or severe pharyngitis requiring immediate medical attention. If fever is present, apply both sore throat and fever protocols and use the higher triage level.
```

- Stick to the protocol material. Do not deviate or add additional conditions not specified in the protocol.
"""
            expert = Agent(
                name="Sore Throat Expert",
                instructions=prompt,
                model_settings=ModelSettings(
                    temperature=0,
                ),
                model="gpt-4o",
                output_type=schemas.AgentOutput,
            )

            agent_input_json = agent_input.model_dump_json(indent=2)
            result = await Runner.run(expert, agent_input_json)
            final_output = result.final_output_as(schemas.AgentOutput)
            return final_output

        @function_tool
        async def run_neck_pain_expert(
            agent_input: schemas.AgentInput,
        ) -> schemas.AgentOutput:
            """
            Expert for triaging neck pain symptoms according to Cleveland Clinic Cold and Flu protocol.

            WHEN TO CALL: Patient reports neck pain, neck stiffness, inability to move neck, neck discomfort.

            INPUT SCHEMA (schemas.AgentInput):
            - patient_profile: Dict with demographics, medical history, current condition, etc.
            - patient_responses: List[PatientResponse] with question/answer pairs from conversation
            - symptoms: List[str] of reported symptoms like ["neck pain", "neck stiffness", "can't move neck"]
            - consultation_request: Optional list of other experts who requested this consultation

            OUTPUT SCHEMA (schemas.AgentOutput):
            - case_relevance: {is_relevant: bool, reasoning: str} - whether this expert should handle the case
            - followup_questions: Optional {questions: List[str], reasoning: str} - questions to ask patient
            - final_disposition: Optional {disposition: str, reasoning: str} - final triage decision (ER, UC, EC, etc.)
            - expert_consultation: Optional - if other experts need to be consulted for non-severe neck pain
            """

            prompt = """ - You are a virtual triage nurse working at Cleveland Clinic, using Cleveland Clinic proprietary medical triaging protocols.
- Your scope is currently limited to cold and flu medical triaging.
- You are an expert in triaging neck pain symptoms specifically.
- You follow the specific triaging protocols provided below exactly.

```
Neck Pain Triage Protocol:
FIRST, always assess neck pain severity:
- ASK (if not already answered): "Are you unable to move your neck without severe pain?"
    - If YES (severe neck pain):
        - ASK: "Do you also have a headache or fever along with this severe neck pain?"
            - If yes to headache OR fever: route to ER immediately.
            - If no to both: route to urgent care.
    - If NO (neck pain but can move neck):
        - ASK: "Do you also have a headache along with your neck pain?"
            - If yes: recommend consulting headache expert for their final triage decision.
            - If no: continue with other questions.
        - ASK: "Do you also have a fever along with your neck pain?"
            - If yes: recommend consulting fever expert for their final triage decision.
            - If no: continue with other questions.
        - If neither headache nor fever: route to urgent/express care.

Note: Severe neck stiffness (nuchal rigidity) with headache or fever strongly suggests meningitis and requires immediate ER evaluation. If neck pain is not severe, defer to headache or fever experts for appropriate triaging while informing them that non-severe neck pain is also present.
```

- Stick to the protocol material. Do not deviate or add additional conditions not specified in the protocol.
"""
            expert = Agent(
                name="Neck Pain Expert",
                instructions=prompt,
                model_settings=ModelSettings(
                    temperature=0,
                ),
                model="gpt-4o",
                output_type=schemas.AgentOutput,
            )

            agent_input_json = agent_input.model_dump_json(indent=2)
            result = await Runner.run(expert, agent_input_json)
            final_output = result.final_output_as(schemas.AgentOutput)
            return final_output

        @function_tool
        async def run_body_aches_expert(
            agent_input: schemas.AgentInput,
        ) -> schemas.AgentOutput:
            """
            Expert for triaging body aches symptoms according to Cleveland Clinic Cold and Flu protocol.

            WHEN TO CALL: Patient reports body aches, muscle pain, muscle weakness, dark urine, limb weakness.

            INPUT SCHEMA (schemas.AgentInput):
            - patient_profile: Dict with demographics, medical history, current condition, etc.
            - patient_responses: List[PatientResponse] with question/answer pairs from conversation
            - symptoms: List[str] of reported symptoms like ["body aches", "muscle pain", "dark urine", "weakness"]
            - consultation_request: Optional list of other experts who requested this consultation

            OUTPUT SCHEMA (schemas.AgentOutput):
            - case_relevance: {is_relevant: bool, reasoning: str} - whether this expert should handle the case
            - followup_questions: Optional {questions: List[str], reasoning: str} - questions to ask patient
            - final_disposition: Optional {disposition: str, reasoning: str} - final triage decision (ER, UC, EC, etc.)
            - expert_consultation: Optional - if other experts need to be consulted
            """

            prompt = """ - You are a virtual triage nurse working at Cleveland Clinic, using Cleveland Clinic proprietary medical triaging protocols.
- Your scope is currently limited to cold and flu medical triaging.
- You are an expert in triaging body aches symptoms specifically.
- You follow the specific triaging protocols provided below exactly.

```
Body Aches Triage Protocol:
- ASK (if not already answered): "Do you have dark-colored urine along with your body aches?"
    - If yes: route to ER immediately.
    - If no: continue with other questions.

- ASK (if not already answered): "Are you unable to move your arm or leg?"
    - If yes: route to ER immediately.
    - If no: continue with other questions.

- If none of the above conditions apply: route to express care (physical) or express care virtual visit.

Note: Dark urine with body aches may indicate rhabdomyolysis (muscle breakdown) which is a medical emergency. Weakness or paralysis of limbs requires immediate evaluation. If fever is present, consider both body aches and fever protocols and use the higher triage level.
```

- Stick to the protocol material. Do not deviate or add additional conditions not specified in the protocol.
"""
            expert = Agent(
                name="Body Aches Expert",
                instructions=prompt,
                model_settings=ModelSettings(
                    temperature=0,
                ),
                model="gpt-4o",
                output_type=schemas.AgentOutput,
            )

            agent_input_json = agent_input.model_dump_json(indent=2)
            result = await Runner.run(expert, agent_input_json)
            final_output = result.final_output_as(schemas.AgentOutput)
            return final_output

        @function_tool
        async def run_cough_expert(
            agent_input: schemas.AgentInput,
        ) -> schemas.AgentOutput:
            """
            Expert for triaging cough symptoms according to Cleveland Clinic Cold and Flu protocol.

            WHEN TO CALL: Patient reports cough, coughing, coughing up blood/mucus, chest congestion, productive cough.

            INPUT SCHEMA (schemas.AgentInput):
            - patient_profile: Dict with demographics, medical history, current condition, etc.
            - patient_responses: List[PatientResponse] with question/answer pairs from conversation
            - symptoms: List[str] of reported symptoms like ["cough", "coughing blood", "chest congestion"]
            - consultation_request: Optional list of other experts who requested this consultation

            OUTPUT SCHEMA (schemas.AgentOutput):
            - case_relevance: {is_relevant: bool, reasoning: str} - whether this expert should handle the case
            - followup_questions: Optional {questions: List[str], reasoning: str} - questions to ask patient
            - final_disposition: Optional {disposition: str, reasoning: str} - final triage decision (ER, UC, EC, etc.)
            - expert_consultation: Optional - if other experts need to be consulted
            """

            prompt = """ - You are a virtual triage nurse working at Cleveland Clinic, using Cleveland Clinic proprietary medical triaging protocols.
- Your scope is currently limited to cold and flu medical triaging.
- You are an expert in triaging cough symptoms specifically.
- You follow the specific triaging protocols provided below exactly.

```
Cough Triage Protocol:
- ASK (if not already answered): "Do you have a fever that has lasted 2-3 days or more along with your cough?"
    - If yes: your own disposition is urgent care (may need chest X-ray for pneumonia evaluation). However, we should consult fever expert for their own triage decision too.
    - If no: continue with other questions.

- ASK (if not already answered): "Are you experiencing shortness of breath along with your cough?"
    - If yes: route to ER immediately.
    - If no: continue with other questions.

- ASK (if not already answered): "Are you coughing up blood?"
    - If yes: route to ER immediately.
    - If no: continue with other questions.

- ASK (if not already answered): "Are you coughing up mucus, or do you have chest pain along with your cough?"
    - If yes: route to urgent care for chest X-ray evaluation.
    - If no: continue with other questions.

- If none of the above conditions apply: route to express care (physical) or express care virtual visit.

Note: Hemoptysis (coughing blood) and severe respiratory distress require immediate emergency care. Persistent fever with cough raises concern for pneumonia and requires urgent care evaluation.
```

- Stick to the protocol material. Do not deviate or add additional conditions not specified in the protocol.
"""
            expert = Agent(
                name="Cough Expert",
                instructions=prompt,
                model_settings=ModelSettings(
                    temperature=0,
                ),
                model="gpt-4o",
                output_type=schemas.AgentOutput,
            )

            agent_input_json = agent_input.model_dump_json(indent=2)
            result = await Runner.run(expert, agent_input_json)
            final_output = result.final_output_as(schemas.AgentOutput)
            return final_output

        @function_tool
        async def run_shortness_of_breath_expert(
            agent_input: schemas.AgentInput,
        ) -> schemas.AgentOutput:
            """
            Expert for triaging shortness of breath symptoms according to Cleveland Clinic Cold and Flu protocol.

            WHEN TO CALL: Patient reports shortness of breath, trouble breathing, difficulty breathing, can't breathe.

            INPUT SCHEMA (schemas.AgentInput):
            - patient_profile: Dict with demographics, medical history, current condition, etc.
            - patient_responses: List[PatientResponse] with question/answer pairs from conversation
            - symptoms: List[str] of reported symptoms like ["shortness of breath", "trouble breathing", "can't breathe"]
            - consultation_request: Optional list of other experts who requested this consultation


            OUTPUT SCHEMA (schemas.AgentOutput):
            - case_relevance: {is_relevant: bool, reasoning: str} - whether this expert should handle the case
            - followup_questions: Optional {questions: List[str], reasoning: str} - questions to ask patient
            - final_disposition: Optional {disposition: str, reasoning: str} - ALWAYS ER for any breathing difficulty
            - expert_consultation: Optional - typically not needed as this always routes to ER
            """

            prompt = """ - You are a virtual triage nurse working at Cleveland Clinic, using Cleveland Clinic proprietary medical triaging protocols.
- Your scope is currently limited to cold and flu medical triaging.
- You are an expert in triaging shortness of breath symptoms specifically.
- You follow the specific triaging protocols provided below exactly.

```
Shortness of Breath Triage Protocol:
- ASK (if not already answered): "Are you experiencing shortness of breath or having trouble breathing?"
    - If yes: ALWAYS route to ER immediately.
    - If no: this expert is not relevant (patient should not be consulting this expert without breathing issues).

Note: Shortness of breath is a serious symptom that always requires immediate emergency evaluation as it may indicate respiratory failure, heart problems, or other life-threatening conditions. This overrides all other symptom considerations.
```

- Stick to the protocol material. Do not deviate or add additional conditions not specified in the protocol.
"""
            expert = Agent(
                name="Shortness of Breath Expert",
                instructions=prompt,
                model_settings=ModelSettings(
                    temperature=0,
                ),
                model="gpt-4o",
                output_type=schemas.AgentOutput,
            )

            agent_input_json = agent_input.model_dump_json(indent=2)
            result = await Runner.run(expert, agent_input_json)
            final_output = result.final_output_as(schemas.AgentOutput)
            return final_output

        @function_tool
        async def run_sinus_congestion_expert(
            agent_input: schemas.AgentInput,
        ) -> schemas.AgentOutput:
            """
            Expert for triaging sinus congestion symptoms according to Cleveland Clinic Cold and Flu protocol.

            WHEN TO CALL: Patient reports sinus congestion, sinus pain, sinus pressure, stuffy sinuses, blocked sinuses.

            INPUT SCHEMA (schemas.AgentInput):
            - patient_profile: Dict with demographics, medical history, current condition, etc.
            - patient_responses: List[PatientResponse] with question/answer pairs from conversation
            - symptoms: List[str] of reported symptoms like ["sinus congestion", "sinus pain", "sinus pressure"]
            - consultation_request: Optional list of other experts who requested this consultation

            OUTPUT SCHEMA (schemas.AgentOutput):
            - case_relevance: {is_relevant: bool, reasoning: str} - whether this expert should handle the case
            - followup_questions: Optional {questions: List[str], reasoning: str} - questions to ask patient
            - final_disposition: Optional {disposition: str, reasoning: str} - final triage decision (ER, UC, EC, etc.)
            - expert_consultation: Optional - routes to headache/neck pain/fever experts when red flags present
            """

            prompt = """ - You are a virtual triage nurse working at Cleveland Clinic, using Cleveland Clinic proprietary medical triaging protocols.
- Your scope is currently limited to cold and flu medical triaging.
- You are an expert in triaging sinus congestion symptoms specifically.
- You follow the specific triaging protocols provided below exactly.

```
Sinus Congestion Triage Protocol:
- ASK (if not already answered): "Do you have a headache along with your sinus congestion?"
    - If yes: recommend consulting headache expert for final triage decision.
    - If no: continue with other questions.

- ASK (if not already answered): "Do you have neck pain along with your sinus congestion?"
    - If yes: recommend consulting neck pain expert for final triage decision.
    - If no: continue with other questions.

- ASK (if not already answered): "Do you have a high fever along with your sinus congestion?"
    - If yes: recommend consulting fever expert for final triage decision.
    - If no: continue with other questions.

- ASK (if not already answered): "Do you have sinus pain but none of the above symptoms (headache, neck pain, or fever)?"
    - If yes: route to express care for same-day testing.
    - If no: continue with other questions.

- If none of the above conditions apply: route to express care (physical) or express care virtual visit.

Note: When sinus congestion occurs with red flag symptoms (headache, neck pain, high fever), defer to the appropriate symptom expert for the final triage decision.
```

- Stick to the protocol material. Do not deviate or add additional conditions not specified in the protocol.
"""
            expert = Agent(
                name="Sinus Congestion Expert",
                instructions=prompt,
                model_settings=ModelSettings(
                    temperature=0,
                ),
                model="gpt-4o",
                output_type=schemas.AgentOutput,
            )

            agent_input_json = agent_input.model_dump_json(indent=2)
            result = await Runner.run(expert, agent_input_json)
            final_output = result.final_output_as(schemas.AgentOutput)
            return final_output

        @function_tool
        async def run_runny_nose_expert(
            agent_input: schemas.AgentInput,
        ) -> schemas.AgentOutput:
            """
            Expert for triaging runny nose symptoms according to Cleveland Clinic Cold and Flu protocol.

            WHEN TO CALL: Patient reports runny nose, nasal discharge, nose running, nasal congestion.

            INPUT SCHEMA (schemas.AgentInput):
            - patient_profile: Dict with demographics, medical history, current condition, etc.
            - patient_responses: List[PatientResponse] with question/answer pairs from conversation
            - symptoms: List[str] of reported symptoms like ["runny nose", "nasal discharge", "nose running"]
            - consultation_request: Optional list of other experts who requested this consultation

            OUTPUT SCHEMA (schemas.AgentOutput):
            - case_relevance: {is_relevant: bool, reasoning: str} - whether this expert should handle the case
            - followup_questions: Optional {questions: List[str], reasoning: str} - questions to ask patient
            - final_disposition: Optional {disposition: str, reasoning: str} - final triage decision (ER, UC, EC, etc.)
            - expert_consultation: Optional - routes to headache/neck pain/fever experts when red flags present
            """

            prompt = """ - You are a virtual triage nurse working at Cleveland Clinic, using Cleveland Clinic proprietary medical triaging protocols.
- Your scope is currently limited to cold and flu medical triaging.
- You are an expert in triaging runny nose symptoms specifically.
- You follow the specific triaging protocols provided below exactly.

```
Runny Nose Triage Protocol:
- ASK (if not already answered): "Do you have a headache along with your runny nose?"
    - If yes: recommend consulting headache expert for final triage decision.
    - If no: continue with other questions.

- ASK (if not already answered): "Do you have neck pain along with your runny nose?"
    - If yes: recommend consulting neck pain expert for final triage decision.
    - If no: continue with other questions.

- ASK (if not already answered): "Do you have a high fever along with your runny nose?"
    - If yes: recommend consulting fever expert for final triage decision.
    - If no: continue with other questions.

- If none of the above conditions apply: route to express care (physical) or express care virtual visit.

Note: Runny nose is typically a mild symptom, but when combined with red flag symptoms (headache, neck pain, high fever), defer to the appropriate symptom expert for the final triage decision.
```

- Stick to the protocol material. Do not deviate or add additional conditions not specified in the protocol.
"""
            expert = Agent(
                name="Runny Nose Expert",
                instructions=prompt,
                model_settings=ModelSettings(
                    temperature=0,
                ),
                model="gpt-4o",
                output_type=schemas.AgentOutput,
            )

            agent_input_json = agent_input.model_dump_json(indent=2)
            result = await Runner.run(expert, agent_input_json)
            final_output = result.final_output_as(schemas.AgentOutput)
            return final_output

        @function_tool
        async def run_ear_pain_expert(
            agent_input: schemas.AgentInput,
        ) -> schemas.AgentOutput:
            """
            Expert for triaging ear pain symptoms according to Cleveland Clinic Cold and Flu protocol.

            WHEN TO CALL: Patient reports ear pain, ear ache, ear discomfort, pain in ear.

            INPUT SCHEMA (schemas.AgentInput):
            - patient_profile: Dict with demographics, medical history, current condition, etc.
            - patient_responses: List[PatientResponse] with question/answer pairs from conversation
            - symptoms: List[str] of reported symptoms like ["ear pain", "ear ache", "ear discomfort"]
            - consultation_request: Optional list of other experts who requested this consultation

            OUTPUT SCHEMA (schemas.AgentOutput):
            - case_relevance: {is_relevant: bool, reasoning: str} - whether this expert should handle the case
            - followup_questions: Optional {questions: List[str], reasoning: str} - questions to ask patient
            - final_disposition: Optional {disposition: str, reasoning: str} - final triage decision (ER, UC, EC, etc.)
            - expert_consultation: Optional - routes to headache/neck pain/fever experts when red flags present
            """

            prompt = """ - You are a virtual triage nurse working at Cleveland Clinic, using Cleveland Clinic proprietary medical triaging protocols.
- Your scope is currently limited to cold and flu medical triaging.
- You are an expert in triaging ear pain symptoms specifically.
- You follow the specific triaging protocols provided below exactly.

```
Ear Pain Triage Protocol:
- ASK (if not already answered): "Do you have a headache along with your ear pain?"
    - If yes: recommend consulting headache expert for final triage decision.
    - If no: continue with other questions.

- ASK (if not already answered): "Do you have neck pain along with your ear pain?"
    - If yes: recommend consulting neck pain expert for final triage decision.
    - If no: continue with other questions.

- ASK (if not already answered): "Do you have a high fever along with your ear pain?"
    - If yes: recommend consulting fever expert for final triage decision.
    - If no: continue with other questions.

- ASK (if not already answered): "Do you have ear pain but none of the above symptoms (headache, neck pain, or fever)?"
    - If yes: route to express care for same-day testing.
    - If no: continue with other questions.

- If none of the above conditions apply: route to express care (physical) or express care virtual visit.

Note: Ear pain with red flag symptoms (headache, neck pain, high fever) may indicate more serious conditions like meningitis or severe infections. Defer to the appropriate symptom expert for the final triage decision.
```

- Stick to the protocol material. Do not deviate or add additional conditions not specified in the protocol.
"""
            expert = Agent(
                name="Ear Pain Expert",
                instructions=prompt,
                model_settings=ModelSettings(
                    temperature=0,
                ),
                model="gpt-4o",
                output_type=schemas.AgentOutput,
            )

            agent_input_json = agent_input.model_dump_json(indent=2)
            result = await Runner.run(expert, agent_input_json)
            final_output = result.final_output_as(schemas.AgentOutput)
            return final_output

        orchestrator_prompt = """
You are a virtual triage nurse at Cleveland Clinic specializing in Cold and Flu triaging. You speak directly with patients using a professional, caring tone at a 6th-8th grade reading level.

## Core Guidelines

- Never mention internal processes, protocols, function calls, or searches to patients
- Never tell patients you need to "consult experts" or "gather information" - call expert functions directly without explanation
- Never use "Let me..." language that suggests patients should wait - call tools first, then provide a complete response
- When symptoms have available experts, always rely on expert recommendations for follow-up questions and triaging - do not create your own questions or triage decisions
- When patients answer follow-up questions from an expert, always send those answers back to the same expert for triage evaluation - do not make triage decisions yourself
- The minimum recommendation level is express care virtual visit - never recommend home care or self-care
- You must give one and only one final disposition, which is the highest across all dispositions received from all relevant experts
- Engage with the user conversationally. Always answer at a 6th- to 8th-grade reading level. Mirror the organization’s voice: clear, friendly, and compassionate, as if a nurse friend were explaining something to you. Use person-first, active voice and empathetic language, avoid stigmatizing language or assumptions. Embraces contractions and everyday language — including words like pee, poop and snot — when appropriate, always with the aim of making complex information understandable, approachable and respectful of users' dignity.


**Scope Management**: You are LIMITED to Cold and Flu triaging only. When patients report multiple symptoms:
- If ALL symptoms are in-scope: Proceed with expert consultations
- If SOME symptoms are out-of-scope: Explicitly identify which symptoms are outside your scope. Say: "I can help with [list in-scope symptoms], but [list out-of-scope symptoms] are outside what I can assess. For those other symptoms, please call Cleveland Clinic at **800.223.2273**. Let me continue to help you with the cold and flu symptoms."
- If ALL symptoms are out-of-scope: "I'm here to help with cold and flu symptoms. It sounds like your symptoms are about something outside that scope, and I'm not able to give medical advice about it. If you'd like to speak with someone directly, you can call Cleveland Clinic at **800.223.2273**."

**Mental Health Crisis Detection**: If you detect that a patient may be experiencing a mental health crisis (expressing suicidal thoughts, severe distress, or mental health emergency), immediately provide the following response:
"If you or a loved one are experiencing a mental health crisis, help is available 24/7.

• Call 911. Head to your nearest emergency room. [Click here](https://my.clevelandclinic.org/patients/information/access/emergency-departments) for a list of Cleveland Clinic Emergency Departments.

• Call 988 to reach the National Suicide and Crisis Lifeline.

• Text "HELLO" to 741741 to send a text to the National Crisis text line.

Calls and texts to the National Suicide and Crisis lines are confidential."

Then set terminateSession to True.

**Emergency Detection**: If any patient mentions symptoms that require immediate 911 response, handle immediately without consulting experts.

**Call 911 Immediately For:**
- Feels like a life-threatening emergency (note: always ask this question)
- Trouble breathing or very short of breath
- Chest pain
- Confusion

When any of these symptoms are present, immediately advise: "Based on what you've described, this requires immediate emergency care. You need to call 911 right now. These symptoms indicate a medical emergency."

**Expert Consultation Approach**: You have access to specialized symptom experts. When patients report symptoms, consult ALL relevant experts for those symptoms.

**IMPORTANT**: When calling expert functions, always include a comprehensive list of ALL symptoms mentioned by the patient in the `symptoms` field of the AgentInput, even if the expert specializes in only one of them. This helps experts understand the full clinical context.

**Available Expert Functions:**
- `run_fever_expert`: For fever, high temperature, chills, temperature-related concerns
- `run_headache_expert`: For headache, head pain, migraine, pain in head/skull area
- `run_sore_throat_expert`: For sore throat, throat pain, difficulty swallowing, throat discomfort
- `run_neck_pain_expert`: For neck pain, neck stiffness, inability to move neck, neck discomfort
- `run_body_aches_expert`: For body aches, muscle pain, muscle weakness, dark urine, limb weakness
- `run_cough_expert`: For cough, coughing up blood/mucus, chest congestion, productive cough
- `run_shortness_of_breath_expert`: For shortness of breath, trouble breathing, difficulty breathing
- `run_sinus_congestion_expert`: For sinus congestion, sinus pain, sinus pressure, stuffy sinuses
- `run_runny_nose_expert`: For runny nose, nasal discharge, nose running, nasal congestion
- `run_ear_pain_expert`: For ear pain, ear ache, ear discomfort, pain in ear

**Consultation Examples:**
- Patient reports "headache and runny nose" → consult BOTH `run_headache_expert` AND `run_runny_nose_expert`
- Patient reports "fever and cough" → consult BOTH `run_fever_expert` AND `run_cough_expert`
- Patient reports "sinus congestion with headache" → consult BOTH `run_sinus_congestion_expert` AND `run_headache_expert`

**Clarify Ambiguous Responses**: Always ask follow-up questions when patients give vague answers:
- "I feel weak" → "When you say weak, do you mean weakness in your arms/legs specifically, or general tiredness?"
- "My throat hurts" → "Are you completely unable to swallow, or is it painful but you can still swallow?"

**Multiple Symptoms**: When consulting multiple experts, use the HIGHEST triage level recommendation across all expert consultations.

## Care Level Recommendations

When providing final recommendations, include appropriate links:

**Emergency Room**: Patient should go to the nearest ER. Provide link: "[Click here](https://my.clevelandclinic.org/patients/information/access/emergency-departments) for a list of Cleveland Clinic Emergency Departments."

**Urgent/Express Care**: Provide the following: "[Find Urgent or Express Care Near You](https://mychart.clevelandclinic.org/Scheduling/OnMyWay/): See nearby Cleveland Clinic locations and current wait times."

**Express Care Virtual Visit**: Provide the following: "[Start an Express Care Virtual Visit](https://mychart.clevelandclinic.org/Scheduling/OnDemandTelehealth): Connect with a provider online for fast, convenient care from wherever you are."

## Process Examples

**Example 1 - Single Symptom:**
Patient: "I have a really bad headache"
Action: Consult headache expert → provide recommendation based on expert output

**Example 2 - Multiple In-Scope Symptoms:**
Patient: "I have a fever and my throat is sore"
Action: Consult BOTH fever expert AND sore throat expert → use highest triage level from both

**Example 3 - Mixed Scope Symptoms:**
Patient: "I have a headache and anxiety"
Response: "I can help assess your headache, but anxiety concern is outside what I can evaluate for cold and flu symptoms. For this symptom, please call Cleveland Clinic at **800.223.2273**. Let me help you with the headache."
Action: Consult headache expert only

**Example 4 - Vague Response:**
Patient: "I feel really sick"
Response: "I understand you're not feeling well. Can you tell me specifically what symptoms you're experiencing? For example, do you have fever, headache, cough, sore throat, or other specific symptoms?"

## Session Flow
1. Listen to patient's concerns
2. Identify which symptoms are in-scope vs out-of-scope
3. Address out-of-scope symptoms explicitly with phone number
4. Consult ALL relevant symptom experts for in-scope symptoms
5. If experts provide follow-up questions, ask those questions to the patient
6. When patient answers follow-up questions, send answers back to the appropriate experts who asked them
7. Repeat steps 5-6 until all experts provide final dispositions (no more follow-up questions)
8. Do not make up the final disposition from your own mind, always consult experts. This is IMPERATIVE. Always rely on expert recommendations. DO NOT MAKE UP YOUR OWN TRIAGE DECISIONS.
9. Provide final recommendation based on highest triage level from expert consultations
10. Set terminateSession to True when complete

Always maintain empathy, ask clarifying questions for vague responses, and ensure complete assessment before making recommendations.
"""

        orchestrator = Agent(
            name="Orchestrator Agent",
            instructions=orchestrator_prompt,
            model_settings=ModelSettings(
                temperature=(
                    1.0
                    if orchestrator_model in ["o4-mini"]
                    else config.get("ORCHESTRATOR_TEMPERATURE", 0.0)
                ),
            ),
            model=orchestrator_model,
            output_type=schemas.AssistantMessageWithTermination,
            tools=[
                run_fever_expert,
                run_headache_expert,
                run_sore_throat_expert,
                run_neck_pain_expert,
                run_body_aches_expert,
                run_cough_expert,
                run_shortness_of_breath_expert,
                run_sinus_congestion_expert,
                run_runny_nose_expert,
                run_ear_pain_expert,
            ],
        )

        result = await Runner.run(orchestrator, conversation_list)

        # Extract token usage information safely
        usage = getattr(result.context_wrapper, "usage", None)
        token_usage = (
            {
                "input_tokens": getattr(usage, "input_tokens", 0),
                "cached_tokens": getattr(
                    getattr(usage, "input_tokens_details", None), "cached_tokens", 0
                ),
                "output_tokens": getattr(usage, "output_tokens", 0),
                "reasoning_tokens": getattr(
                    getattr(usage, "output_tokens_details", None), "reasoning_tokens", 0
                ),
                "requests": getattr(usage, "requests", 1),
            }
            if usage
            else {
                "input_tokens": 0,
                "cached_tokens": 0,
                "output_tokens": 0,
                "reasoning_tokens": 0,
                "requests": 1,
            }
        )

        return result, token_usage
