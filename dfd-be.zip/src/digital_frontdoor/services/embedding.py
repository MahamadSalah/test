from abc import ABC, abstractmethod
from typing import List, Dict
import digital_frontdoor.schemas as schemas
from digital_frontdoor.config import get_config, get_credential
import logging
import tiktoken

from openai import AsyncOpenAI, AzureOpenAI
from azure.identity import get_bearer_token_provider


config = get_config()

logger = logging.getLogger(__name__)


class EmbeddingProvider(ABC):
    @abstractmethod
    async def embed_text(self, text: str):
        pass

    @abstractmethod
    def get_tokens_from_string(
        self, string: str, encoding_name: str = "cl100k_base"
    ) -> List[int]:
        pass

    @abstractmethod
    def get_string_from_tokens(
        self, tokens: List[int], encoding_name: str = "cl100k_base"
    ) -> str:
        pass


class OpenAIEmbeddings(EmbeddingProvider):
    def __init__(self):
        self.client = AsyncOpenAI()

    async def embed_text(self, text: str):
        return await self.client.embeddings.create(
            input=text, model=config.get("EMBEDDING_MODEL", "text-embedding-3-small")
        )

    def num_tokens_from_string(
        self, string: str, encoding_name: str = "cl100k_base"
    ) -> int:
        """Returns the number of tokens in a text string."""
        encoding = tiktoken.get_encoding(encoding_name)
        num_tokens = len(encoding.encode(string))
        return num_tokens

    def get_tokens_from_string(
        self, string: str, encoding_name: str = "cl100k_base"
    ) -> List[int]:
        """Returns the tokens of a text string."""
        encoding = tiktoken.get_encoding(encoding_name)
        return encoding.encode(string)

    def get_string_from_tokens(
        self, tokens: List[int], encoding_name: str = "cl100k_base"
    ) -> str:
        """Convert tokens back to a text string."""
        encoding = tiktoken.get_encoding(encoding_name)
        return encoding.decode(tokens)


class AzureOpenAIEmbedding(EmbeddingProvider):
    def __init__(self):
        token_provider = get_bearer_token_provider(
            get_credential(), "https://cognitiveservices.azure.com/.default"
        )

        self.client = AzureOpenAI(
            api_version=config.get("AZURE_API_VERSION", "2024-12-01-preview"),
            azure_endpoint=config.get("AZURE_API_BASE", ""),
            azure_ad_token_provider=token_provider,
        )

    async def embed_text(self, text: str):
        return self.client.embeddings.create(
            input=text, model=config.get("EMBEDDING_MODEL", "text-embedding-3-small")
        )

    def num_tokens_from_string(
        self, string: str, encoding_name: str = "cl100k_base"
    ) -> int:
        """Returns the number of tokens in a text string."""
        encoding = tiktoken.get_encoding(encoding_name)
        num_tokens = len(encoding.encode(string))
        return num_tokens

    def get_tokens_from_string(
        self, string: str, encoding_name: str = "cl100k_base"
    ) -> List[int]:
        """Returns the tokens of a text string."""
        encoding = tiktoken.get_encoding(encoding_name)
        return encoding.encode(string)

    def get_string_from_tokens(
        self, tokens: List[int], encoding_name: str = "cl100k_base"
    ) -> str:
        """Convert tokens back to a text string."""
        encoding = tiktoken.get_encoding(encoding_name)
        return encoding.decode(tokens)
