"""
Triage Service - Handles state-driven triage flow logic
"""

from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from uuid import uuid4
import digital_frontdoor.schemas as schemas
from digital_frontdoor.services import crud
from digital_frontdoor.content.messages import (
    create_initial_messages,
    create_call_911_multiselect,
    create_call_911_text_question,
    create_go_to_er_multiselect,
    create_call_911_recommendation,
    create_er_recommendation,
)


class TriageService:
    """Service class for handling state-driven triage logic"""

    async def handle_initial_session(
        self, db: AsyncSession, session_id: str, is_simulation: bool = False
    ) -> schemas.MessageExchangeResponse:
        """
        Handle initial session - send greeting and Call 911 questions

        Args:
            db: Database session
            session_id: Session ID
            is_simulation: Whether this is simulation mode (affects 911 question format)

        Returns:
            MessageExchangeResponse with initial messages
        """
        # Set initial state
        await crud.update_session_state_async(db, session_id, "init")

        # Create initial messages with UUIDs
        message_ids = [str(uuid4()), str(uuid4())]
        initial_messages = create_initial_messages(message_ids)

        # Create Call 911 question (format depends on simulation mode)
        if is_simulation:
            call_911_message = create_call_911_text_question(str(uuid4()))
        else:
            call_911_message = create_call_911_multiselect(str(uuid4()))

        # Update state to indicate call 911 questions are sent
        await crud.update_session_state_async(db, session_id, "call_911_questions_sent")

        return schemas.MessageExchangeResponse(
            messages=initial_messages + [call_911_message]
        )

    async def handle_call_911_response(
        self,
        db: AsyncSession,
        session_id: str,
        user_messages: List[schemas.BackendMessage],
    ) -> Optional[schemas.MessageExchangeResponse]:
        """
        Handle user response to Call 911 questions

        Args:
            db: Database session
            session_id: Session ID
            user_messages: List of user messages

        Returns:
            MessageExchangeResponse if handling this state, None otherwise
        """
        # Find the most recent user text message (messages are ordered by timestamp)
        latest_user_message = None
        for msg in reversed(user_messages):
            if msg.sender == "user" and msg.type == "text":
                latest_user_message = msg
                break

        if not latest_user_message or not latest_user_message.content:
            return None

        # If user selected "None of the above", proceed to ER questions
        # TODO: This is really a hardcoded text matching approach, beware of potential issues
        if "None of the above" in latest_user_message.content:
            await crud.update_session_state_async(db, session_id, "er_questions_sent")
            er_message = create_go_to_er_multiselect(str(uuid4()))
            return schemas.MessageExchangeResponse(messages=[er_message])
        else:
            # User selected symptoms, recommend calling 911 and terminate session
            await crud.update_session_state_async(
                db, session_id, "call_911_recommended"
            )
            await crud.terminate_session_async(db, session_id)
            call_911_message = create_call_911_recommendation(str(uuid4()))
            call_911_message.terminateSession = True
            return schemas.MessageExchangeResponse(messages=[call_911_message])

    async def handle_er_response(
        self,
        db: AsyncSession,
        session_id: str,
        user_messages: List[schemas.BackendMessage],
    ) -> Optional[schemas.MessageExchangeResponse]:
        """
        Handle user response to ER questions

        Args:
            db: Database session
            session_id: Session ID
            user_messages: List of user messages

        Returns:
            MessageExchangeResponse if handling this state, None otherwise
        """
        # Find the most recent user text message (messages are ordered by timestamp)
        latest_user_message = None
        for msg in reversed(user_messages):
            if msg.sender == "user" and msg.type == "text":
                latest_user_message = msg
                break

        if not latest_user_message or not latest_user_message.content:
            return None

        # If user selected "None of the above", hand off to orchestrator
        if "None of the above" in latest_user_message.content:
            await crud.update_session_state_async(
                db, session_id, "orchestrator_handling"
            )
            return None  # Signal to hand off to orchestrator
        else:
            # User selected symptoms, recommend going to ER and terminate session
            await crud.update_session_state_async(db, session_id, "er_recommended")
            await crud.terminate_session_async(db, session_id)
            er_message = create_er_recommendation(str(uuid4()))
            er_message.terminateSession = True
            return schemas.MessageExchangeResponse(messages=[er_message])

    async def process_message_exchange(
        self,
        db: AsyncSession,
        session_id: str,
        request: schemas.MessageExchangeRequest,
        existing_message_ids: set,
    ) -> Optional[schemas.MessageExchangeResponse]:
        """
        Process message exchange based on current session state

        Args:
            db: Database session
            session_id: Session ID
            request: Message exchange request
            existing_message_ids: Set of existing message IDs

        Returns:
            MessageExchangeResponse if handled by triage logic, None if should hand off to orchestrator
        """

        # Get current session state
        current_state = await crud.get_current_session_state_async(db, session_id)
        state_value = current_state.state if current_state else "init"

        # Handle based on current state
        if state_value == "call_911_questions_sent":
            return await self.handle_call_911_response(db, session_id, request.messages)

        elif state_value == "er_questions_sent":
            return await self.handle_er_response(db, session_id, request.messages)

        # If state is "orchestrator_handling" or other states, return None to signal orchestrator handoff
        return None


# Singleton instance
triage_service = TriageService()


def get_triage_service() -> TriageService:
    """Dependency injection function for FastAPI"""
    return triage_service
