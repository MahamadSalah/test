import digital_frontdoor.schemas as schemas
import json
import uuid

from sqlalchemy.orm import Session
from sqlalchemy.ext.asyncio import AsyncSession
from digital_frontdoor.models import models
from typing import List, Optional, Literal
from sqlalchemy.sql.expression import func
from sqlalchemy import select


async def get_session_by_id_async(
    db: AsyncSession,
    session_id: str,
) -> models.Session:
    """Async version of get_session_by_id"""
    result = await db.execute(
        select(models.Session).filter(models.Session.session_id == session_id)
    )
    return result.scalar_one_or_none()


async def create_new_session_async(
    db: AsyncSession,
    session_id: str,
) -> models.Session:
    """Async version of create_new_session"""
    new_session = models.Session(session_id=session_id)
    db.add(new_session)
    await db.commit()
    await db.refresh(new_session)
    return new_session


async def get_or_create_session_async(
    db: AsyncSession,
    session_id: str,
) -> models.Session:
    """Async version of get_or_create_session"""
    session = await get_session_by_id_async(db, session_id)
    if not session:
        session = await create_new_session_async(db, session_id)
    return session


async def get_next_sequence_for_session_async(db: AsyncSession, session_id: str) -> int:
    """Async version of get_next_sequence_for_session"""
    result = await db.execute(
        select(func.max(models.Conversation.sequence)).filter(
            models.Conversation.session_id == session_id
        )
    )
    max_sequence = result.scalar()
    return (max_sequence or 0) + 1


async def get_conversations_by_session_id_async(
    db: AsyncSession,
    session_id: str,
) -> List[models.Conversation]:
    """Async version of get_conversations_by_session_id"""
    session = await get_session_by_id_async(db, session_id)
    if not session:
        return []

    # Sort by sequence instead of date_created
    result = await db.execute(
        select(models.Conversation)
        .filter(models.Conversation.session_id == session_id)
        .order_by(models.Conversation.sequence)
    )
    return result.scalars().all()


async def get_message_objects_by_session_id_async(
    db: AsyncSession,
    session_id: str,
) -> List[schemas.Message]:
    """Async version of get_message_objects_by_session_id"""
    conversations = await get_conversations_by_session_id_async(db, session_id)
    messages = []
    for conv in conversations:
        messages.append(
            schemas.Message(
                session_uuid=session_id,
                message_uuid=conv.message_id,
                content=conv.message_content,
                type=conv.message_type or "text",  # Use database column
            )
        )
    return messages


async def create_full_conversation_history_async(
    db: AsyncSession,
    session_id: str,
    conversations: List[dict],
    model_name: str = None,
    tracing_url: str = None,
):
    """Async version of create_full_conversation_history"""
    session = await get_session_by_id_async(db, session_id)
    if not session:
        raise ValueError(f"Session {session_id} does not exist")

    # Get the starting sequence number
    starting_sequence = await get_next_sequence_for_session_async(db, session_id)

    for i, conversation_item in enumerate(conversations):
        # Simply dump the entire conversation item as JSON
        db_content = json.dumps(conversation_item.get("raw_item"))
        message_id = str(uuid.uuid4())

        conversation = models.Conversation(
            session_id=session_id,
            message_id=message_id,
            message_content=db_content,
            sequence=starting_sequence + i,
            model_name=model_name,
            tracing_url=tracing_url,
        )
        db.add(conversation)

    await db.commit()


async def terminate_session_async(
    db: AsyncSession,
    session_id: str,
) -> models.Session:
    """Set terminated flag to True for a session"""
    session = await get_session_by_id_async(db, session_id)
    if not session:
        raise ValueError(f"Session {session_id} does not exist")

    session.terminated = True
    await db.commit()
    await db.refresh(session)
    return session


async def is_session_terminated_async(
    db: AsyncSession,
    session_id: str,
) -> bool:
    """Check if a session is terminated"""
    session = await get_session_by_id_async(db, session_id)
    if not session:
        return False
    return session.terminated


def convert_backend_message_to_llm_content(msg: schemas.BackendMessage) -> str:
    """
    Convert a BackendMessage to LLM-friendly content string.
    Handles text, mcq, multiselect, and form message types.
    """
    if msg.type == "text":
        return msg.content
    elif msg.type == "mcq":
        if hasattr(msg, "selectedValues") and msg.selectedValues:
            # User response - show question and selected answer
            return f"Question: {msg.question}\nAnswer: {', '.join(msg.selectedValues)}"
        else:
            # Assistant question - show question with all options
            options_text = "\n".join([f"- {option.text}" for option in msg.options])
            return f"Question: {msg.question}\nOptions:\n{options_text}"
    elif msg.type == "multiselect":
        if hasattr(msg, "selectedValues") and msg.selectedValues:
            # User response - show question and selected answers
            return f"Question: {msg.question}\nAnswers: {', '.join(msg.selectedValues)}"
        else:
            # Assistant question - show question with all options
            options_text = "\n".join([f"- {option.text}" for option in msg.options])
            return f"Question: {msg.question}\nOptions:\n{options_text}"
    elif msg.type == "form":
        if hasattr(msg, "values") and msg.values:
            # User response - show form with filled values
            form_data = []
            for field in msg.fields:
                value = msg.values.get(field.id, "")
                if value:
                    form_data.append(f"{field.label}: {value}")
            if form_data:
                return f"Form: {msg.title}\n" + "\n".join(form_data)
            else:
                return f"Form: {msg.title}"
        else:
            # Assistant form - show form with field descriptions
            fields_text = "\n".join(
                [f"- {field.label} ({field.type})" for field in msg.fields]
            )
            return f"Form: {msg.title}\nFields:\n{fields_text}"
    else:
        return str(msg)


async def get_existing_message_ids_async(db: AsyncSession, session_id: str) -> set:
    """
    Get all existing message IDs from the database for a session.
    Returns a set of message IDs that have already been stored.
    """
    existing_conversations = await get_conversations_by_session_id_async(db, session_id)
    existing_message_ids = set()

    for conv in existing_conversations:
        # Use the actual message_id from the Conversation model, not from JSON content
        existing_message_ids.add(conv.message_id)

    return existing_message_ids


async def persist_new_backend_messages_async(
    db: AsyncSession,
    session_id: str,
    messages: List[schemas.BackendMessage],
    existing_message_ids: set,
) -> List[schemas.BackendMessage]:
    """
    Persist only new BackendMessages to the database.

    Args:
        db: Database session
        session_id: Session ID
        messages: List of BackendMessages from frontend
        existing_message_ids: Set of message IDs already in database

    Returns:
        List of new messages that were persisted
    """
    # Filter out messages that already exist in the database
    new_messages = [msg for msg in messages if msg.id not in existing_message_ids]

    if not new_messages:
        return []

    # Get the starting sequence number for new messages
    starting_sequence = await get_next_sequence_for_session_async(db, session_id)
    sequence_counter = 0

    for msg in new_messages:
        content = convert_backend_message_to_llm_content(msg)
        role = "user" if msg.sender == "user" else "assistant"

        # Create conversation entry with LLM-friendly format
        message_content = {
            "role": role,
            "content": content,
        }

        conversation = models.Conversation(
            session_id=session_id,
            message_id=msg.id,  # Use the frontend message ID
            message_content=json.dumps(message_content),
            message_type=msg.type,  # Store in database column
            sequence=starting_sequence + sequence_counter,
        )
        db.add(conversation)
        sequence_counter += 1

    await db.commit()
    return new_messages


async def convert_conversations_to_orchestrator_messages_async(
    db: AsyncSession, session_id: str, session_uuid: str
) -> List[schemas.Message]:
    """
    Convert stored conversations to schemas.Message format for orchestrator.

    Args:
        db: Database session
        session_id: Session ID
        session_uuid: Session UUID for the Message objects

    Returns:
        List of schemas.Message objects for orchestrator
    """
    all_messages = await get_message_objects_by_session_id_async(db, session_id)
    orchestrator_messages = []

    for msg_obj in all_messages:
        try:
            # Create a schemas.Message-like object for orchestrator
            orchestrator_msg = schemas.Message(
                session_uuid=session_uuid,
                message_uuid=msg_obj.message_uuid,  # Use the actual message_uuid from the object
                content=msg_obj.content,  # Pass the full JSON string as content
                type=msg_obj.type
                or "text",  # Use type from message object (from database column)
            )
            orchestrator_messages.append(orchestrator_msg)
        except (json.JSONDecodeError, KeyError):
            continue

    return orchestrator_messages


async def persist_assistant_message_async(
    db: AsyncSession,
    session_id: str,
    message_id: str,
    content: str,
    model_name: str = None,
    tracing_url: str = None,
) -> None:
    """
    Persist a single assistant message to the database.

    Args:
        db: Database session
        session_id: Session ID
        message_id: UUID for the message
        content: Message content
        model_name: Optional model name used to generate the message
        tracing_url: Optional URL for tracing this message generation
    """
    # Get the next sequence number
    sequence = await get_next_sequence_for_session_async(db, session_id)

    # Create conversation entry with LLM-friendly format
    message_content = {
        "role": "assistant",
        "content": content,
    }

    conversation = models.Conversation(
        session_id=session_id,
        message_id=message_id,  # Use the provided message_id
        message_content=json.dumps(message_content),
        message_type="text",  # Store in database column
        sequence=sequence,
        model_name=model_name,
        tracing_url=tracing_url,
    )
    db.add(conversation)
    await db.commit()


async def create_prompt_storage_async(
    db: AsyncSession,
    session_id: str,
    input_guardrail_prompt: str,
    orchestrator_prompt: str,
    name: str = "",
    memo: str = "",
) -> models.PromptStorage:
    """
    Create a new prompt storage entry.

    Args:
        db: Database session
        session_id: Session ID
        input_guardrail_prompt: Guardrail prompt content
        orchestrator_prompt: Orchestrator prompt content
        name: Optional name (default empty string)
        memo: Optional memo (default empty string)

    Returns:
        Created PromptStorage object
    """
    prompt_id = str(uuid.uuid4())

    prompt_storage = models.PromptStorage(
        id=prompt_id,
        session_id=session_id,
        input_guardrail_prompt=input_guardrail_prompt,
        orchestrator_prompt=orchestrator_prompt,
        name=name or "",  # Ensure empty string if None
        memo=memo or "",  # Ensure empty string if None
    )

    db.add(prompt_storage)
    await db.commit()
    await db.refresh(prompt_storage)

    return prompt_storage


async def create_session_rating_async(
    db: AsyncSession,
    session_id: str,
    rating: int,
    feedback: str = "",
) -> models.SessionRating:
    """
    Create a new session rating entry.

    Args:
        db: Database session
        session_id: Session ID
        rating: Rating value (integer)
        feedback: Optional feedback text (default empty string)

    Returns:
        Created SessionRating object
    """
    rating_id = str(uuid.uuid4())

    session_rating = models.SessionRating(
        id=rating_id,
        session_id=session_id,
        rating=rating,
        feedback=feedback or "",  # Ensure empty string if None
    )

    db.add(session_rating)
    await db.commit()
    await db.refresh(session_rating)

    return session_rating


async def create_session_state_async(
    db: AsyncSession,
    session_id: str,
    state: str,
) -> models.SessionState:
    """
    Create a new session state entry.

    Args:
        db: Database session
        session_id: Session ID
        state: Current state value

    Returns:
        Created SessionState object
    """
    state_id = str(uuid.uuid4())

    session_state = models.SessionState(
        id=state_id,
        session_id=session_id,
        state=state,
    )

    db.add(session_state)
    await db.commit()
    await db.refresh(session_state)

    return session_state


async def get_current_session_state_async(
    db: AsyncSession, session_id: str
) -> Optional[models.SessionState]:
    """
    Get the most recent session state for a session.

    Args:
        db: Database session
        session_id: Session ID

    Returns:
        Latest SessionState object or None if not found
    """
    from sqlalchemy import select

    result = await db.execute(
        select(models.SessionState)
        .filter(models.SessionState.session_id == session_id)
        .order_by(models.SessionState.date_updated.desc())
        .limit(1)
    )
    return result.scalars().first()


async def update_session_state_async(
    db: AsyncSession,
    session_id: str,
    new_state: str,
) -> models.SessionState:
    """
    Update the session state. Creates new entry or updates existing one.

    Args:
        db: Database session
        session_id: Session ID
        new_state: New state value

    Returns:
        Updated SessionState object
    """
    from datetime import datetime, timezone

    # Get current state record
    current_state = await get_current_session_state_async(db, session_id)

    if current_state:
        # Update existing record
        current_state.state = new_state
        current_state.date_updated = datetime.now(timezone.utc)
        await db.commit()
        await db.refresh(current_state)
        return current_state
    else:
        # Create new record if none exists
        return await create_session_state_async(db, session_id, new_state)


async def create_session_evaluation_async(
    db: AsyncSession,
    session_id: str,
    recommendation_matches: bool,
    recommended_destinations: List[str] = None,
    current_destinations: List[str] = None,
    comments: str = "",
    name: str = "",
    agent_experience: Literal["default", "panel"] = "default",
    conversation_history: List[dict] = None,
    input_guardrail_prompt: str = None,
    orchestrator_prompt: str = None,
    patient_simulator_prompt: str = None,
) -> models.SessionEvaluation:
    """
    Create a new session evaluation entry.

    Args:
        db: Database session
        session_id: Session ID
        recommendation_matches: Whether recommendation matches current destinations
        recommended_destinations: List of recommended destinations
        current_destinations: List of current destinations
        comments: Optional comments text
        conversation_history: List of conversation messages
        input_guardrail_prompt: Input guardrail prompt text
        orchestrator_prompt: Orchestrator prompt text
        patient_simulator_prompt: Patient simulator prompt text

    Returns:
        Created SessionEvaluation object
    """
    evaluation_id = str(uuid.uuid4())

    session_evaluation = models.SessionEvaluation(
        id=evaluation_id,
        session_id=session_id,
        name=name,
        agent_experience=agent_experience,
        recommendation_matches=recommendation_matches,
        recommended_destinations=json.dumps(recommended_destinations or []),
        current_destinations=json.dumps(current_destinations or []),
        comments=comments or "",
        conversation_history=json.dumps(conversation_history or []),
        input_guardrail_prompt=input_guardrail_prompt,
        orchestrator_prompt=orchestrator_prompt,
        patient_simulator_prompt=patient_simulator_prompt,
    )

    db.add(session_evaluation)
    await db.commit()
    await db.refresh(session_evaluation)

    return session_evaluation


async def get_token_usage_by_session_id_async(
    db: AsyncSession, session_id: str
) -> Optional[models.TokenUsage]:
    """
    Get token usage for a session.

    Args:
        db: Database session
        session_id: Session ID

    Returns:
        TokenUsage object or None if not found
    """
    result = await db.execute(
        select(models.TokenUsage).filter(models.TokenUsage.session_id == session_id)
    )
    return result.scalar_one_or_none()


async def create_or_update_token_usage_async(
    db: AsyncSession,
    session_id: str,
    input_tokens: int,
    cached_tokens: int,
    output_tokens: int,
    reasoning_tokens: int,
    requests: int = 1,
) -> models.TokenUsage:
    """
    Create or update token usage for a session.

    Args:
        db: Database session
        session_id: Session ID
        input_tokens: Number of input tokens
        cached_tokens: Number of cached tokens
        output_tokens: Number of output tokens
        reasoning_tokens: Number of reasoning tokens
        requests: Number of requests (default 1)

    Returns:
        Updated or created TokenUsage object
    """
    from datetime import datetime, timezone

    # Try to get existing token usage
    existing_usage = await get_token_usage_by_session_id_async(db, session_id)

    if existing_usage:
        # Update existing record
        existing_usage.total_input_tokens += input_tokens
        existing_usage.total_cached_tokens += cached_tokens
        existing_usage.total_output_tokens += output_tokens
        existing_usage.total_reasoning_tokens += reasoning_tokens
        existing_usage.total_requests += requests
        existing_usage.date_updated = datetime.now(timezone.utc)

        await db.commit()
        await db.refresh(existing_usage)
        return existing_usage
    else:
        # Create new record
        token_usage = models.TokenUsage(
            session_id=session_id,
            total_input_tokens=input_tokens,
            total_cached_tokens=cached_tokens,
            total_output_tokens=output_tokens,
            total_reasoning_tokens=reasoning_tokens,
            total_requests=requests,
        )

        db.add(token_usage)
        await db.commit()
        await db.refresh(token_usage)
        return token_usage


async def get_token_usage_detail_by_session_and_agent_async(
    db: AsyncSession, session_id: str, agent_type: str
) -> Optional[models.TokenUsageDetail]:
    """
    Get existing token usage detail for a specific session and agent type.

    Args:
        db: Database session
        session_id: Session ID
        agent_type: Type of agent ("guardrail" or "orchestrator")

    Returns:
        TokenUsageDetail object or None if not found
    """
    result = await db.execute(
        select(models.TokenUsageDetail).filter(
            models.TokenUsageDetail.session_id == session_id,
            models.TokenUsageDetail.agent_type == agent_type,
        )
    )
    return result.scalar_one_or_none()


async def create_or_update_token_usage_detail_async(
    db: AsyncSession,
    session_id: str,
    agent_type: str,
    model_name: str,
    input_tokens: int,
    cached_tokens: int,
    output_tokens: int,
    reasoning_tokens: int,
    requests: int = 1,
) -> models.TokenUsageDetail:
    """
    Create or update a detailed token usage record for a specific agent invocation.

    Args:
        db: Database session
        session_id: Session ID
        agent_type: Type of agent ("guardrail" or "orchestrator")
        model_name: Name of the model used
        input_tokens: Number of input tokens
        cached_tokens: Number of cached tokens
        output_tokens: Number of output tokens
        reasoning_tokens: Number of reasoning tokens
        requests: Number of requests (default 1)

    Returns:
        Created or updated TokenUsageDetail object
    """
    from datetime import datetime, timezone

    # Try to get existing detail record for this session and agent type
    existing_detail = await get_token_usage_detail_by_session_and_agent_async(
        db, session_id, agent_type
    )

    if existing_detail:
        # Update existing record by adding new token usage
        existing_detail.input_tokens += input_tokens
        existing_detail.cached_tokens += cached_tokens
        existing_detail.output_tokens += output_tokens
        existing_detail.reasoning_tokens += reasoning_tokens
        existing_detail.requests += requests
        # Update model name in case it changed
        existing_detail.model_name = model_name

        await db.commit()
        await db.refresh(existing_detail)
        return existing_detail
    else:
        # Create new record
        detail_id = str(uuid.uuid4())

        token_usage_detail = models.TokenUsageDetail(
            id=detail_id,
            session_id=session_id,
            agent_type=agent_type,
            model_name=model_name,
            input_tokens=input_tokens,
            cached_tokens=cached_tokens,
            output_tokens=output_tokens,
            reasoning_tokens=reasoning_tokens,
            requests=requests,
        )

        db.add(token_usage_detail)
        await db.commit()
        await db.refresh(token_usage_detail)
        return token_usage_detail


async def get_token_usage_details_by_session_id_async(
    db: AsyncSession, session_id: str
) -> List[models.TokenUsageDetail]:
    """
    Get all token usage details for a session.

    Args:
        db: Database session
        session_id: Session ID

    Returns:
        List of TokenUsageDetail objects
    """
    result = await db.execute(
        select(models.TokenUsageDetail)
        .filter(models.TokenUsageDetail.session_id == session_id)
        .order_by(models.TokenUsageDetail.date_created)
    )
    return result.scalars().all()
