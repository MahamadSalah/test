import os
from fastapi import (
    FastAPI,
    Depends,
    Header,
    Request,
)
from typing import Optional
from digital_frontdoor.services import (
    get_database_service,
    get_orchestrator_service,
    OrchestratorService,
    crud,
)
from digital_frontdoor.services.triage_service import get_triage_service, TriageService
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi import HTTPException
from fastapi.middleware.cors import CORSMiddleware
import traceback
from sqlalchemy.ext.asyncio import AsyncSession
import digital_frontdoor.schemas as schemas
from digital_frontdoor.config import get_config, Config
import json
import logging
from uuid import uuid4
from datetime import datetime

# Configure logging
LOG_FMT = "%(asctime)s %(levelname)s [%(name)s] %(pathname)s:%(lineno)d in %(funcName)s | %(message)s"

# Configure root logger to capture all module logs
logging.basicConfig(
    level=logging.ERROR,
    format=LOG_FMT,
    handlers=[
        logging.StreamHandler(),
    ],
)

API_KEY = os.getenv("API_KEY", "change-this-key")

# Get root logger to capture logs from all modules
root_logger = logging.getLogger()
# Also get module-specific logger for backwards compatibility
logger = logging.getLogger(__name__)

config = get_config()

app = FastAPI(
    title="Digital Front Door", description="AI Assistant for Virtual Triaging"
)


def validate_api_key(x_api_key: Optional[str] = Header(None)):
    if not x_api_key or x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return x_api_key


# Global exception handler to catch all unhandled exceptions
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """
    Global exception handler that captures all unhandled exceptions
    and logs them with full traceback information.
    """
    # Log the full exception with traceback
    root_logger.error(
        f"Unhandled exception occurred: {str(exc)}\n"
        f"Request: {request.method} {request.url}\n"
        f"Traceback: {traceback.format_exc()}",
        exc_info=True,
    )

    # Return a generic error response to the client (same format as FastAPI default)
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Internal server error occurred. Please try again later.",
            "error_id": str(uuid4()),  # Unique error ID for tracking
        },
    )


# Configure CORS for dev environment
origins = [
    "https://salmon-mushroom-009f5010f.1.azurestaticapps.net",
    "https://salmon-mushroom-009f5010f-preview.eastus2.1.azurestaticapps.net",
    "https://dfd.ccf.org",
    "https://dfd-test.ccf.org",
    "http://localhost:5173",
    "http://localhost:4173",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health_check_api(api_key: str = Depends(validate_api_key)):
    return {"status": "healthy"}


@app.post("/api/patient", response_model=schemas.MessageExchangeResponse)
async def handle_patient_request_api(
    request: schemas.PatientRequest,
    async_db: AsyncSession = Depends(get_database_service().get_async_db),
    api_key: str = Depends(validate_api_key),
):
    """
    Handle Patient simulation.
    TODO: Proper implementation that relies on DIP. Currently uses a direct agent import.
    """
    from agents import (
        Agent,
        Runner,
    )

    conversation = []
    for msg in request.messages:
        content = crud.convert_backend_message_to_llm_content(msg)
        # Intentionally invert roles for the patient agent simulation
        role = "assistant" if msg.sender == "user" else "user"

        # Create conversation entry with LLM-friendly format
        message_content = {
            "role": role,
            "content": content,
        }
        conversation.append(message_content)

    orchestrator = Agent(
        name="Patient AI Agent Simulator",
        instructions=request.patientPrompt,
        model="gpt-4o",
    )

    result = await Runner.run(orchestrator, conversation)

    reply_message = [
        schemas.TextMessage(
            id=str(uuid4()),
            timestamp=datetime.now().isoformat(),
            sender="user",
            type="text",
            content=result.final_output,
        )
    ]
    return schemas.MessageExchangeResponse(messages=reply_message)


@app.post("/api/message", response_model=schemas.MessageExchangeResponse)
async def handle_message_exchange_api(
    request: schemas.MessageExchangeRequest,
    async_db: AsyncSession = Depends(get_database_service().get_async_db),
    triage_service: TriageService = Depends(get_triage_service),
    api_key: str = Depends(validate_api_key),
):
    """
    Handle message exchange between the backend and the new frontend.
    If no messages are provided, return the initial greeting messages.
    """

    # Ensure session exists (create if needed)
    session = await crud.get_or_create_session_async(async_db, request.sessionId)

    # Extract session_id immediately while in async context
    session_id = session.session_id

    # Check if session has been terminated
    is_terminated = await crud.is_session_terminated_async(async_db, session_id)
    if is_terminated:
        termination_message = schemas.TextMessage(
            id=str(uuid4()),
            timestamp=datetime.now().isoformat(),
            sender="assistant",
            type="text",
            content="This session has ended. Please start a new chat if you need any help.",
        )
        return schemas.MessageExchangeResponse(messages=[termination_message])

    if not request.messages:
        # New session - handle with triage service
        # Notice that messages won't be persisted yet
        # They will be after the user responds to the initial messages
        return await triage_service.handle_initial_session(
            async_db, session_id, request.is_simulation
        )
    else:
        # Get existing message IDs to identify new messages
        existing_message_ids = await crud.get_existing_message_ids_async(
            async_db, session_id
        )

        # Persist new messages
        await crud.persist_new_backend_messages_async(
            async_db, session_id, request.messages, existing_message_ids
        )

        orchestrator_service = get_orchestrator_service(request.agent_experience)
        agent_panel = True if request.agent_experience == "panel" else False
        if (not agent_panel) and (not request.is_simulation):
            # We are essentially ignoring the determinstic triaging logic for 911 and ER questions
            # in simulation mode to allow free-text conversation between both agents
            # In non-simulation mode, if triage_response is not None, it means the determinstic triage logic handled it
            # which means this has to do with 911 or ER questions

            # Try to handle with triage service first in case this is a response to 911 or ER questions
            # Note that message persistence is handled inside the triage service
            # So you can't really remove this piece without changing that
            triage_response = await triage_service.process_message_exchange(
                async_db, session_id, request, existing_message_ids
            )

            if triage_response:
                return triage_response

        # Otherwise, hand off to orchestrator
        # Convert stored conversations to orchestrator format
        # TODO: This is a bit of overkill. We could probably already leverage the message persisting logic above
        orchestrator_messages = (
            await crud.convert_conversations_to_orchestrator_messages_async(
                async_db, session_id, request.sessionId
            )
        )

        # Call orchestrator if we have messages
        if orchestrator_messages:
            assistant_content, trace_url = await orchestrator_service.answer(
                db=async_db,
                messages=orchestrator_messages,
                session_id=session_id,
                orchestrator_model=config.get("ORCHESTRATOR_MODEL"),
                guardrail_model=config.get("GUARDRAIL_MODEL"),
                prompts=request.promptSettings,
            )
        else:
            raise HTTPException(status_code=500, detail="No messages to process")

        # Create assistant response message with our own UUID
        assistant_message_id = str(uuid4())
        assistant_timestamp = datetime.now().isoformat()

        # Check if session got terminated during the response generation
        is_terminated = await crud.is_session_terminated_async(async_db, session_id)

        assistant_message = schemas.TextMessage(
            id=assistant_message_id,
            timestamp=assistant_timestamp,
            sender="assistant",
            type="text",
            content=assistant_content,
            terminateSession=is_terminated,
        )

        # Persist the assistant message to database
        await crud.persist_assistant_message_async(
            async_db,
            session_id,
            assistant_message_id,
            assistant_content,
            model_name=config.get("ORCHESTRATOR_MODEL"),
            tracing_url=trace_url,
        )

        # Return all messages including the new assistant response
        return schemas.MessageExchangeResponse(messages=[assistant_message])


@app.post("/api/savePrompts", response_model=schemas.SavePromptsResponse)
async def save_prompts_api(
    request: schemas.SavePromptsRequest,
    async_db: AsyncSession = Depends(get_database_service().get_async_db),
    api_key: str = Depends(validate_api_key),
):
    """
    Save prompts for a session.
    Stores input guardrail prompt and orchestrator prompt with optional name and memo.
    """
    try:
        # Create new prompt storage entry
        prompt_storage = await crud.create_prompt_storage_async(
            db=async_db,
            session_id=request.session_id,
            input_guardrail_prompt=request.input_guardrail_prompt,
            orchestrator_prompt=request.orchestrator_prompt,
            name=request.name or "",
            memo=request.memo or "",
        )

        return schemas.SavePromptsResponse(
            success=True,
            prompt_id=prompt_storage.id,
        )

    except Exception as e:
        logger.error(f"Error saving prompts: {str(e)}", exc_info=True)
        return schemas.SavePromptsResponse(
            success=False,
            error=str(e),
        )


@app.post("/api/rating", response_model=schemas.RatingResponse)
async def submit_rating_api(
    request: schemas.RatingRequest,
    async_db: AsyncSession = Depends(get_database_service().get_async_db),
    api_key: str = Depends(validate_api_key),
):
    """
    Submit a rating for a session.
    Stores the rating and optional feedback for the session.
    """
    try:
        # Create new session rating entry
        session_rating = await crud.create_session_rating_async(
            db=async_db,
            session_id=request.session_id,
            rating=request.rating,
            feedback=request.feedback or "",
        )

        return schemas.RatingResponse(
            success=True,
            rating_id=session_rating.id,
        )

    except Exception as e:
        logger.error(f"Error saving rating: {str(e)}", exc_info=True)
        return schemas.RatingResponse(
            success=False,
            error=str(e),
        )


@app.post("/api/evaluate", response_model=schemas.EvaluationResponse)
async def submit_evaluation_api(
    request: schemas.EvaluationRequest,
    async_db: AsyncSession = Depends(get_database_service().get_async_db),
    api_key: str = Depends(validate_api_key),
):
    """
    Submit an evaluation for a session.
    Stores the evaluation data including recommendation matches, destinations, comments,
    conversation history, and prompt settings.
    """
    try:
        # Convert Pydantic models to dicts for JSON serialization
        conversation_history_dicts = [
            msg.model_dump() for msg in request.conversation_history
        ]

        # Extract individual prompt fields from prompt_settings
        input_guardrail_prompt = getattr(
            request.prompt_settings, "inputGuardrail", None
        )
        orchestrator_prompt = getattr(request.prompt_settings, "orchestrator", None)
        patient_simulator_prompt = getattr(
            request.prompt_settings, "patientSimulator", None
        )

        # Create new session evaluation entry
        session_evaluation = await crud.create_session_evaluation_async(
            db=async_db,
            session_id=request.session_id,
            recommendation_matches=request.recommendation_matches,
            recommended_destinations=request.recommended_destinations or [],
            current_destinations=request.current_destinations or [],
            comments=request.comments or "",
            name=request.name or "",
            agent_experience=request.agent_experience or "default",
            conversation_history=conversation_history_dicts,
            input_guardrail_prompt=input_guardrail_prompt,
            orchestrator_prompt=orchestrator_prompt,
            patient_simulator_prompt=patient_simulator_prompt,
        )

        return schemas.EvaluationResponse(
            success=True,
            evaluation_id=session_evaluation.id,
        )

    except Exception as e:
        logger.error(f"Error saving evaluation: {str(e)}", exc_info=True)
        return schemas.EvaluationResponse(
            success=False,
            error=str(e),
        )


@app.get("/api/token-usage/{session_id}", response_model=schemas.TokenUsageResponse)
async def get_token_usage_api(
    session_id: str,
    async_db: AsyncSession = Depends(get_database_service().get_async_db),
    api_key: str = Depends(validate_api_key),
):
    """
    Get token usage information for a session.
    Returns both summary totals and detailed breakdown by agent type.
    """
    try:
        # Get summary token usage
        token_usage = await crud.get_token_usage_by_session_id_async(
            async_db, session_id
        )

        # Get detailed token usage
        token_details = await crud.get_token_usage_details_by_session_id_async(
            async_db, session_id
        )

        # Convert to response schemas and calculate costs efficiently
        details = []
        total_session_cost = 0.0

        # Calculate cost once per detail record and build response objects
        for detail in token_details:
            detail_cost = Config.calculate_token_cost(
                model_name=detail.model_name,
                input_tokens=detail.input_tokens,
                cached_tokens=detail.cached_tokens,
                output_tokens=detail.output_tokens,
                reasoning_tokens=detail.reasoning_tokens,
            )
            total_session_cost += detail_cost

            details.append(
                schemas.TokenUsageDetail(
                    id=detail.id,
                    agent_type=detail.agent_type,
                    model_name=detail.model_name,
                    input_tokens=detail.input_tokens,
                    cached_tokens=detail.cached_tokens,
                    output_tokens=detail.output_tokens,
                    reasoning_tokens=detail.reasoning_tokens,
                    requests=detail.requests,
                    cost_usd=round(detail_cost, 6),
                    date_created=detail.date_created.isoformat(),
                )
            )

        # Create summary with aggregated cost
        summary = None
        if token_usage:
            summary = schemas.TokenUsageSummary(
                session_id=token_usage.session_id,
                total_input_tokens=token_usage.total_input_tokens,
                total_cached_tokens=token_usage.total_cached_tokens,
                total_output_tokens=token_usage.total_output_tokens,
                total_reasoning_tokens=token_usage.total_reasoning_tokens,
                total_requests=token_usage.total_requests,
                total_cost_usd=round(total_session_cost, 6),
                date_created=token_usage.date_created.isoformat(),
                date_updated=token_usage.date_updated.isoformat(),
            )

        return schemas.TokenUsageResponse(
            success=True,
            summary=summary,
            details=details,
        )

    except Exception as e:
        logger.error(
            f"Error retrieving token usage for session {session_id}: {str(e)}",
            exc_info=True,
        )
        return schemas.TokenUsageResponse(
            success=False,
            error=str(e),
        )
