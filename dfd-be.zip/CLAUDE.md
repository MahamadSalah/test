# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview
Digital Front Door AI Assistant for Virtual Medical Triaging - a FastAPI backend service that provides AI-powered medical triage conversations using Azure OpenAI and cloud services.

## Common Development Commands

### Setup and Dependencies
```bash
poetry install                                    # Install dependencies
poetry run alembic upgrade head                   # Run database migrations
```

### Running the Application
```bash
poetry run python src/digital_frontdoor/main.py  # Development server
poetry run gunicorn digital_frontdoor.main:app -w 4 -k uvicorn.workers.UvicornWorker  # Production server
docker-compose up                                 # Full stack (OpenSearch, MySQL, nginx)
```

### Database Operations
```bash
poetry run alembic revision --autogenerate -m "description"  # Create migration
poetry run alembic upgrade head                              # Apply migrations
```

### Code Formatting
```bash
poetry run black .                               # Format code
```

## Architecture Overview

### Core Application Structure
- **Entry Point**: `src/digital_frontdoor/main.py` - FastAPI application
- **Business Logic**: `src/digital_frontdoor/services/` - Service layer with orchestrator, triage, and AI agents
- **Data Models**: `src/digital_frontdoor/models/models.py` - SQLAlchemy database models
- **API Schemas**: `src/digital_frontdoor/schemas.py` - Pydantic request/response models
- **Configuration**: `src/digital_frontdoor/config.py` - Azure credentials and app settings

### Key Services
- **Orchestrator** (`services/orchestrator.py`): Main AI conversation coordinator
- **Triage Service** (`services/triage_service.py`): Medical triage logic with emergency detection
- **Agent** (`services/agent.py`): AI agent implementations using Azure OpenAI
- **MCP Server** (`services/mcp_server.py`): Model Context Protocol server for AI coordination

### Database Architecture
- **Primary**: PostgreSQL with Azure AD authentication
- **Local Development**: MySQL fallback
- **Key Models**: Session, Conversation, PromptStorage, TokenUsage, SessionRating
- **Migrations**: Alembic-managed in `src/digital_frontdoor/migrations/`

### Technology Stack
- **Framework**: FastAPI with async/await
- **AI/ML**: Azure OpenAI (GPT-4o), OpenAI Agents, Sentence Transformers
- **Search**: OpenSearch and Azure Cognitive Search
- **Deployment**: Docker with Gunicorn/Uvicorn workers
- **Dependencies**: Poetry for package management

## Development Patterns

### Async Architecture
All services use async/await patterns. Database operations use AsyncSession, and AI model calls are async.

### Service Injection
Services are injected as dependencies in FastAPI routes. Key dependencies: `get_db_session`, `get_orchestrator_service`, `get_triage_service`.

### Azure Integration
- Managed Identity authentication for Azure services
- Cost tracking for AI model usage via TokenUsage models
- Azure OpenAI client configuration in `config.py`

### Medical Domain Specifics
- Emergency detection (911/ER scenarios) in triage logic
- Session termination controls for medical conversations
- Conversation evaluation and feedback systems

## Environment Configuration
- Copy `.env.sample` to `.env` and configure Azure credentials
- Azure OpenAI endpoint and deployment names required
- Database connection strings for PostgreSQL/MySQL

## Docker Development
Full development stack available via `docker-compose up` including:
- Application server
- OpenSearch for search indexing
- MySQL for local database
- Nginx reverse proxy