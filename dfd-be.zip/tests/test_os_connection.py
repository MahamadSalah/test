#!/usr/bin/env python3
import os
import sys
from opensearchpy import OpenSearch, RequestsHttpConnection
import mysql.connector
from mysql.connector import Error as MySQLError

from dotenv import load_dotenv, find_dotenv

load_dotenv(find_dotenv())


def create_opensearch_client():
    host = os.getenv("OPENSEARCH_HOST", "localhost")
    port = int(os.getenv("OPENSEARCH_PORT", 9200))

    http_auth = None
    user = os.getenv("OPENSEARCH_USERNAME")
    pw = os.getenv("OPENSEARCH_PASSWORD")
    if user and pw:
        http_auth = (user, pw)

    return OpenSearch(
        hosts=[{"host": host, "port": port}],
        http_auth=http_auth,
        use_ssl=False,
        verify_certs=False,
        connection_class=RequestsHttpConnection,
    )


def create_mysql_connection():
    host = os.getenv("MYSQL_HOST", "localhost")
    port = int(os.getenv("MYSQL_PORT", 3306))
    user = os.getenv("MYSQL_USER", "root")
    password = os.getenv("MYSQL_ROOT_PASSWORD", "")
    database = os.getenv("MYSQL_DATABASE", None)

    return mysql.connector.connect(
        host=host, port=port, user=user, password=password, database=database
    )


def main():
    # --- OpenSearch check ---
    os_client = create_opensearch_client()
    try:
        if not os_client.ping():
            print("❌ Unable to ping OpenSearch", file=sys.stderr)
            sys.exit(1)
    except Exception as e:
        print("❌ Error connecting to OpenSearch:", e, file=sys.stderr)
        sys.exit(1)
    print("✅ Connected to OpenSearch!")

    aliases = os_client.indices.get_alias(index="*")
    print("\nIndices in cluster:")
    for idx in sorted(aliases.keys()):
        print(" •", idx)

    # --- MySQL check ---
    try:
        mysql_conn = create_mysql_connection()
        # `ping()` will raise if the connection is down
        mysql_conn.ping(reconnect=True, attempts=3, delay=2)
        print("\n✅ Connected to MySQL!")
    except MySQLError as err:
        print(f"❌ Error connecting to MySQL: {err}", file=sys.stderr)
        sys.exit(1)
    finally:
        if "mysql_conn" in locals() and mysql_conn.is_connected():
            mysql_conn.close()


if __name__ == "__main__":
    main()
