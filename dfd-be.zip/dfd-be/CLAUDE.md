# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview
Digital Front Door is a FastAPI-based virtual triage system that implements the Schmitt-Thompson protocols for patient symptom assessment. It serves as an AI-powered assistant for virtual triaging, helping patients determine the appropriate level of care needed (EMS 911, ED, PCP, Home Care).

## Architecture

### Core Components
- **FastAPI Application** (`src/digital_frontdoor/main.py`) - Main web server with streaming chat endpoint at `/chat`
- **Orchestrator Service** (`src/digital_frontdoor/services/orchestrator.py`) - Core AI logic using OpenAI Agents framework with guardrails and token management
- **Database Models** (`src/digital_frontdoor/models/models.py`) - SQLAlchemy models for Sessions and Conversations
- **Prompt Factory** (`src/digital_frontdoor/services/prompts.py`) - Contains the Schmitt-Thompson Back Pain protocol and guardrail logic
- **CRUD Operations** (`src/digital_frontdoor/services/crud.py`) - Database operations for sessions and conversations
- **Configuration** (`src/digital_frontdoor/config.py`) - Environment-based configuration management

### Data Flow
1. User message received at `/chat` endpoint
2. Session management via database (create/retrieve session)
3. Message stored in conversations table
4. Orchestrator processes message through:
   - Guardrail agent (scope validation)
   - Main triage agent (Schmitt-Thompson protocol)
   - Streaming response generation
5. Assistant response stored and streamed back

### External Dependencies
- **OpenSearch** - Document/index storage (port 9200)
- **MySQL** - Relational data storage (port 3306)
- **OpenAI API** - LLM inference via openai-agents library

## Development Commands

### Environment Setup
```bash
# Install dependencies
poetry install

# Start infrastructure services
docker-compose up -d

# Test database connections
python tests/test_os_connection.py
```

### Development Server
```bash
# Run FastAPI server
uvicorn src.digital_frontdoor.main:app --reload --host 0.0.0.0 --port 8000
```

### Code Quality
```bash
# Format code
black src/ tests/

# Database migrations
alembic upgrade head
```

### Testing
```bash
# Test infrastructure connections
python tests/test_os_connection.py
```

## Environment Configuration
Required environment variables (use `.env` file):
- `MYSQL_ROOT_PASSWORD` - MySQL root password
- `MYSQL_DATABASE` - Database name (default: "dfd")
- `MYSQL_HOST` - MySQL host (default: "localhost")
- `OPENSEARCH_HOST` - OpenSearch host (default: "localhost")
- `OPENSEARCH_PASSWORD` - OpenSearch password
- `OPENAI_API_KEY` - OpenAI API key for LLM inference

## Key Patterns

### Message Schema
All chat interactions use structured message objects with:
- `session_uuid` - Session identifier
- `message_uuid` - Unique message ID
- `assistant_message_uuid` - Assistant response ID
- `sender` - "user" or "assistant"
- `content` - Message text

### Streaming Response
The `/chat` endpoint returns Server-Sent Events with JSON payloads:
- `{'type': 'content', 'message': 'text'}` - Streaming content
- `{'type': 'stream-end', 'message': ''}` - End marker

### Triage Protocol
Currently implements only Back Pain protocol from Schmitt-Thompson guidelines. The system:
1. Validates questions are within scope (medical triage only)
2. Asks triage questions in severity order (highest acuity first)
3. Stops at first positive response and provides appropriate disposition
4. Dispositions: "Call EMS 911 Now", "Go to ED Now", "See HCP Within 4 Hours", etc.

## File Structure Notes
- `src/digital_frontdoor/st_pdfs/` - Contains original Schmitt-Thompson protocol PDFs
- `src/digital_frontdoor/st_gemini_ocr/` - JSON extracts from PDFs (currently only back_pain.json used)
- `migrations/` - Alembic database migration files