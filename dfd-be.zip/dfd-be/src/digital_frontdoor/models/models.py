from sqlalchemy import Column, ForeignKey, DateTime, String, Text, Integer, Boolean
from sqlalchemy.sql import func
from sqlalchemy.orm import declarative_base, relationship
from datetime import datetime, timezone

Base = declarative_base()


class Session(Base):
    __tablename__ = "sessions"

    session_id = Column(
        String(36), primary_key=True  # Not auto-generated, comes from FE
    )
    date_created = Column(DateTime(timezone=True), server_default=func.now())
    terminated = Column(Boolean, default=False, nullable=False)

    # Relationships
    conversations = relationship(
        "Conversation", back_populates="session", cascade="all, delete-orphan"
    )


class Conversation(Base):
    __tablename__ = "conversations"

    session_id = Column(
        String(36),
        ForeignKey("sessions.session_id", ondelete="CASCADE"),
        nullable=False,
    )
    message_id = Column(String(36), primary_key=True)

    message_content = Column(Text, nullable=False)
    message_type = Column(String(50), nullable=True, default="text")
    sequence = Column(Integer, nullable=False)
    model_name = Column(String(255), nullable=True)
    tracing_url = Column(String(512), nullable=True)
    date_created = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),  # Python‐side, tz-aware
        server_default=func.now(),  # DB‐side fallback
        nullable=False,
    )

    # Relationships
    session = relationship("Session", back_populates="conversations")


class PromptStorage(Base):
    __tablename__ = "prompt_storage"

    id = Column(String(36), primary_key=True)  # UUID as string
    session_id = Column(
        String(36),
        ForeignKey("sessions.session_id", ondelete="CASCADE"),
        nullable=False,
    )
    input_guardrail_prompt = Column(Text, nullable=False)
    orchestrator_prompt = Column(Text, nullable=False)
    name = Column(String(255), nullable=True, default="")
    memo = Column(Text, nullable=True, default="")
    date_created = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),  # Python‐side, tz-aware
        server_default=func.now(),  # DB‐side fallback
        nullable=False,
    )

    # Relationships
    session = relationship("Session")


class SessionRating(Base):
    __tablename__ = "session_ratings"

    id = Column(String(36), primary_key=True)  # UUID as string
    session_id = Column(
        String(36),
        ForeignKey("sessions.session_id", ondelete="CASCADE"),
        nullable=False,
    )
    rating = Column(Integer, nullable=False)
    feedback = Column(Text, nullable=True, default="")
    date_created = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),  # Python‐side, tz-aware
        server_default=func.now(),  # DB‐side fallback
        nullable=False,
    )

    # Relationships
    session = relationship("Session")


class SessionState(Base):
    __tablename__ = "session_states"

    id = Column(String(36), primary_key=True)  # UUID as string
    session_id = Column(
        String(36),
        ForeignKey("sessions.session_id", ondelete="CASCADE"),
        nullable=False,
    )
    state = Column(String(255), nullable=False)
    date_created = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),  # Python‐side, tz-aware
        server_default=func.now(),  # DB‐side fallback
        nullable=False,
    )
    date_updated = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),  # Python‐side, tz-aware
        server_default=func.now(),  # DB‐side fallback
        onupdate=lambda: datetime.now(timezone.utc),  # Python‐side update
        nullable=False,
    )

    # Relationships
    session = relationship("Session")


class SessionEvaluation(Base):
    __tablename__ = "session_evaluations"

    id = Column(String(36), primary_key=True)  # UUID as string
    session_id = Column(
        String(36),
        ForeignKey("sessions.session_id", ondelete="CASCADE"),
        nullable=False,
    )
    recommendation_matches = Column(Boolean, nullable=False)
    recommended_destinations = Column(Text, nullable=True)  # JSON array as text
    current_destinations = Column(Text, nullable=True)  # JSON array as text
    comments = Column(Text, nullable=True, default="")
    conversation_history = Column(Text, nullable=False)  # JSON as text
    input_guardrail_prompt = Column(Text, nullable=True)
    orchestrator_prompt = Column(Text, nullable=True)
    patient_simulator_prompt = Column(Text, nullable=True)
    date_created = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),  # Python‐side, tz-aware
        server_default=func.now(),  # DB‐side fallback
        nullable=False,
    )

    # Relationships
    session = relationship("Session")


class TokenUsage(Base):
    __tablename__ = "token_usage"

    session_id = Column(
        String(36),
        ForeignKey("sessions.session_id", ondelete="CASCADE"),
        primary_key=True,
    )
    total_input_tokens = Column(Integer, nullable=False, default=0)
    total_cached_tokens = Column(Integer, nullable=False, default=0)
    total_output_tokens = Column(Integer, nullable=False, default=0)
    total_reasoning_tokens = Column(Integer, nullable=False, default=0)
    total_requests = Column(Integer, nullable=False, default=0)
    date_created = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),  # Python‐side, tz-aware
        server_default=func.now(),  # DB‐side fallback
        nullable=False,
    )
    date_updated = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),  # Python‐side, tz-aware
        server_default=func.now(),  # DB‐side fallback
        onupdate=lambda: datetime.now(timezone.utc),  # Python‐side update
        nullable=False,
    )

    # Relationships
    session = relationship("Session")


class TokenUsageDetail(Base):
    __tablename__ = "token_usage_details"

    id = Column(String(36), primary_key=True)  # UUID as string
    session_id = Column(
        String(36),
        ForeignKey("sessions.session_id", ondelete="CASCADE"),
        nullable=False,
    )
    agent_type = Column(String(50), nullable=False)  # "guardrail" or "orchestrator"
    model_name = Column(String(255), nullable=True)
    input_tokens = Column(Integer, nullable=False, default=0)
    cached_tokens = Column(Integer, nullable=False, default=0)
    output_tokens = Column(Integer, nullable=False, default=0)
    reasoning_tokens = Column(Integer, nullable=False, default=0)
    requests = Column(Integer, nullable=False, default=1)
    date_created = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),  # Python‐side, tz-aware
        server_default=func.now(),  # DB‐side fallback
        nullable=False,
    )

    # Relationships
    session = relationship("Session")
