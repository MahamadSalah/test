from typing import Any, Dict
import os

from dotenv import load_dotenv, find_dotenv
from azure.identity import DefaultAzureCredential, ManagedIdentityCredential
from azure.core.exceptions import ClientAuthenticationError
import logging

logger = logging.getLogger(__name__)

load_dotenv(find_dotenv())


def get_credential():
    """
    Get the appropriate credential based on environment

    This function will:
    - Use DefaultAzureCredential when running locally (developer credentials)
    - Use ManagedIdentityCredential when deployed to Azure

    DefaultAzureCredential tries multiple authentication methods:
    1. Environment variables (AZURE_CLIENT_ID, AZURE_TENANT_ID, AZURE_CLIENT_SECRET)
    2. Managed Identity
    3. Visual Studio Code credentials
    4. Azure CLI credentials
    5. Azure PowerShell credentials
    6. Interactive browser login (as a last resort)
    """
    # Check if running in Azure (IDENTITY_ENDPOINT is set in App Service, Functions, Container Apps)
    is_in_azure = os.environ.get("IDENTITY_ENDPOINT") is not None

    # Get client_id for user-assigned managed identity (if specified)
    client_id = os.environ.get("AZURE_CLIENT_ID")

    if is_in_azure:
        if client_id:
            # Use user-assigned managed identity in Azure
            logger.info(
                f"Running in Azure: Using user-assigned managed identity with client ID: {client_id}"
            )
            return ManagedIdentityCredential(client_id=client_id)
        else:
            # Use system-assigned managed identity in Azure
            logger.info("Running in Azure: Using system-assigned managed identity")
            return ManagedIdentityCredential()
    else:
        # Running locally - use developer's credentials
        logger.info(
            "Running locally: Using DefaultAzureCredential for developer authentication"
        )
        return DefaultAzureCredential()


def get_azure_postgres_password():
    """Get Azure PostgreSQL access token for authentication using Azure SDK"""
    try:
        credential = get_credential()
        token = credential.get_token(
            "https://ossrdbms-aad.database.windows.net/.default"
        )
        return token.token
    except (ClientAuthenticationError, Exception) as e:
        logger.warning(f"Failed to get Azure PostgreSQL token: {e}")
        # Fallback to environment variable if credential fails
        return os.getenv("PGPASSWORD", "")


def get_fresh_postgres_url():
    """Generate PostgreSQL URL with fresh token for each connection"""
    fresh_token = get_azure_postgres_password()
    return f"postgresql+asyncpg://{os.getenv('PGUSER', '')}:{fresh_token}@{os.getenv('PGHOST', 'localhost')}:{os.getenv('PGPORT', 5432)}/{os.getenv('PGDATABASE', 'db-digitalfrontdoor')}?ssl=require"


def get_postgres_url_without_password():
    """Generate PostgreSQL URL without password - for use with callable password in connect_args"""
    return f"postgresql+asyncpg://{os.getenv('PGUSER', '')}@{os.getenv('PGHOST', 'localhost')}:{os.getenv('PGPORT', 5432)}/{os.getenv('PGDATABASE', 'db-digitalfrontdoor')}?ssl=require"


def get_fresh_postgres_sync_url():
    """Generate synchronous PostgreSQL URL with fresh token for migrations"""
    fresh_token = get_azure_postgres_password()
    return f"postgresql+psycopg2://{os.getenv('PGUSER', '')}:{fresh_token}@{os.getenv('PGHOST', 'localhost')}:{os.getenv('PGPORT', 5432)}/{os.getenv('PGDATABASE', 'db-digitalfrontdoor')}?ssl=require"


class Config:
    # Database selection - use PostgreSQL if PGUSER is configured, otherwise MySQL
    USE_POSTGRESQL: bool = bool(os.getenv("PGUSER"))

    # Azure OpenAI Configuration
    AZURE_API_BASE: str = os.getenv("AZURE_API_BASE", "")
    AZURE_API_VERSION: str = os.getenv("AZURE_API_VERSION", "2024-12-01-preview")

    # Azure Cognitive Search Configuration
    AZURE_SEARCH_SERVICE_NAME: str = os.getenv("AZURE_SEARCH_SERVICE_NAME", "")
    AZURE_SEARCH_ENDPOINT: str = os.getenv("AZURE_SEARCH_ENDPOINT", "")
    AZURE_SEARCH_INDEX_NAME: str = os.getenv(
        "AZURE_SEARCH_INDEX_NAME", "medical_protocols"
    )

    GUARDRAIL_MODEL: str = "gpt-4o"
    GUARDRAIL_TEMPERATURE: float = 0

    # "litellm/gemini/gemini-2.5-flash"
    # "litellm/anthropic/claude-sonnet-4-20250514"
    ORCHESTRATOR_MODEL: str = "gpt-4o"
    ORCHESTRATOR_CHAT_TOKENS: int = 120000
    ORCHESTRATOR_TEMPERATURE: float = 0

    # model_name = "text-embedding-3-small" but deployment = "embedding"
    EMBEDDING_MODEL: str = "embedding"
    EMBEDDING_DIM: int = 1536
    EMBEDDING_MAX_CONTEXT: int = 8191

    token_cost = {
        "gpt-4o": {
            "input": 2.5e-6,
            "cached": 1.25e-6,
            "output": 10e-6,
            "reasoning": 10e-6,
        },
    }

    @classmethod
    def calculate_token_cost(
        cls,
        model_name: str,
        input_tokens: int,
        cached_tokens: int,
        output_tokens: int,
        reasoning_tokens: int,
    ) -> float:
        """
        Calculate the cost in USD for token usage based on model pricing.

        Args:
            model_name: Name of the model used
            input_tokens: Number of input tokens
            cached_tokens: Number of cached tokens
            output_tokens: Number of output tokens
            reasoning_tokens: Number of reasoning tokens

        Returns:
            Cost in USD
        """
        if not model_name:
            return 0.0

        pricing = cls.token_cost.get(model_name)
        if not pricing:
            return 0.0

        # Calculate novel (non-cached) input tokens
        novel_input_tokens = max(0, input_tokens - cached_tokens)

        cost = (
            novel_input_tokens * pricing.get("input", 0.0)
            + cached_tokens * pricing.get("cached", 0.0)
            + output_tokens * pricing.get("output", 0.0)
            + reasoning_tokens * pricing.get("reasoning", 0.0)
        )

        return round(cost, 6)  # Round to 6 decimal places for precision


def get_config() -> Dict[str, Any]:
    return Config.__dict__
