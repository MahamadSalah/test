from pydantic import BaseModel, Field, field_validator
from typing import List, Dict, Any, Optional, Union, Literal, Union


class PromptSettings(BaseModel):
    inputGuardrail: str
    orchestrator: str
    patientSimulator: Optional[str] = None


class ValueWithUnit(BaseModel):
    value: str
    unit: str


class Message(BaseModel):
    session_uuid: str
    message_uuid: str
    content: str
    type: Optional[str] = (
        "text"  # "text", "mcq", "form", "multi_select", "form_with_units"
    )


class GuardrailOutput(BaseModel):
    is_within_scope: bool
    reasoning: str


class BaseMessage(BaseModel):
    id: str  # UUID as string
    timestamp: str  # ISO datetime string
    sender: Literal["user", "assistant"]
    terminateSession: Optional[bool] = False


# Text message
class TextMessage(BaseMessage):
    type: Literal["text"]
    content: str


# MCQ option
class MCQOption(BaseModel):
    id: str
    text: str
    value: str


# MCQ message
class MCQMessage(BaseMessage):
    type: Literal["mcq"]
    question: str
    options: List[MCQOption]
    allowMultiple: Optional[bool] = False
    selectedValues: Optional[List[str]] = None


# Form field
class FormField(BaseModel):
    id: str
    type: Literal["text", "number", "email", "tel", "textarea"]
    label: str
    placeholder: Optional[str] = None
    required: Optional[bool] = False


# Form message
class FormMessage(BaseMessage):
    type: Literal["form"]
    title: str
    description: Optional[str] = None
    fields: List[FormField]
    values: Optional[Dict[str, str]] = None


# Multi-select option (separate from MCQOption)
class MultiSelectOption(BaseModel):
    id: str
    text: str
    value: str
    selected: Optional[bool] = None
    exclusive: Optional[bool] = False


# Multi-select message
class MultiSelectMessage(BaseMessage):
    type: Literal["multiselect"]
    question: str
    options: List[MultiSelectOption]  # Changed from MCQOption to MultiSelectOption
    minSelections: Optional[int] = None
    maxSelections: Optional[int] = None
    selectedValues: Optional[List[str]] = None


# Union type for all message types
BackendMessage = Union[TextMessage, MCQMessage, FormMessage, MultiSelectMessage]


# Request/Response models
class MessageExchangeRequest(BaseModel):
    sessionId: str
    messages: List[BackendMessage]
    promptSettings: PromptSettings
    is_simulation: Optional[bool] = False


class PatientRequest(BaseModel):
    sessionId: str
    messages: List[BackendMessage]
    patientPrompt: str


class MessageExchangeResponse(BaseModel):
    messages: List[BackendMessage]


# SavePrompts models
class SavePromptsRequest(BaseModel):
    session_id: str
    input_guardrail_prompt: str
    orchestrator_prompt: str
    name: Optional[str] = ""
    memo: Optional[str] = ""


class SavePromptsResponse(BaseModel):
    success: bool
    prompt_id: Optional[str] = None
    error: Optional[str] = None


# Rating models
class RatingRequest(BaseModel):
    session_id: str
    rating: int
    feedback: Optional[str] = ""


class RatingResponse(BaseModel):
    success: bool
    rating_id: Optional[str] = None
    error: Optional[str] = None


class AssistantMessageWithTermination(BaseModel):
    """
    Message from the assistant with optional session termination flag.
    If terminateSession is True, the frontend should end the session after displaying this message.
    content: The message text to display to the user. It can include markdown formatting. It should be your full natural response to the user.
    terminateSession: Whether to terminate the session after this message.
    """

    content: str
    terminateSession: bool = False


class EvaluationRequest(BaseModel):
    session_id: str
    recommendation_matches: bool
    recommended_destinations: Optional[List[str]] = []
    current_destinations: Optional[List[str]] = []
    comments: Optional[str] = ""
    conversation_history: List[BackendMessage]
    prompt_settings: PromptSettings


class EvaluationResponse(BaseModel):
    success: bool
    evaluation_id: Optional[str] = None
    error: Optional[str] = None


class TokenUsageDetail(BaseModel):
    id: str
    agent_type: str  # "guardrail" or "orchestrator"
    model_name: Optional[str]
    input_tokens: int
    cached_tokens: int
    output_tokens: int
    reasoning_tokens: int
    requests: int
    cost_usd: Optional[float] = None  # Cost in USD for this detail record
    date_created: str  # ISO datetime string


class TokenUsageSummary(BaseModel):
    session_id: str
    total_input_tokens: int
    total_cached_tokens: int
    total_output_tokens: int
    total_reasoning_tokens: int
    total_requests: int
    total_cost_usd: Optional[float] = None  # Total cost in USD for the session
    date_created: str  # ISO datetime string
    date_updated: str  # ISO datetime string


class TokenUsageResponse(BaseModel):
    success: bool
    summary: Optional[TokenUsageSummary] = None
    details: Optional[List[TokenUsageDetail]] = None
    error: Optional[str] = None
