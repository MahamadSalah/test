from digital_frontdoor.config import get_config, get_credential
from abc import ABC, abstractmethod
from opensearchpy import AsyncOpenSearch, AIOHttpConnection

# Azure Cognitive Search imports
from azure.search.documents.aio import SearchClient
from azure.search.documents.indexes.aio import SearchIndexClient
from azure.search.documents.models import VectorizedQuery
from azure.search.documents.indexes.models import (
    SearchIndex,
    SearchField,
    SearchFieldDataType,
    SimpleField,
    SearchableField,
    VectorSearch,
    VectorSearchProfile,
    HnswAlgorithmConfiguration,
)

# from sentence_transformers import SentenceTransformer
from typing import Dict, Any, List
import logging
import hashlib
import json
import argparse
import time
import asyncio

config = get_config()
logger = logging.getLogger(__name__)

# Reduce Azure SDK verbosity
logging.getLogger("azure.core.pipeline.policies.http_logging_policy").setLevel(
    logging.WARNING
)
logging.getLogger("azure.search.documents").setLevel(logging.WARNING)
logging.getLogger("azure.core").setLevel(logging.WARNING)


class IndexService(ABC):
    @abstractmethod
    async def index_document(self, document: Dict[str, Any]) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def create_index_if_not_exists(self) -> bool:
        pass

    @abstractmethod
    async def search_documents(
        self,
        classification: str,
        gender: str,
        keywords: List[str],
        query: str,
        top_k: int,
    ) -> str:
        pass

    @abstractmethod
    async def get_documents_by_ids(self, ids: List[str]) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def get_documents_by_titles(self, titles: List[str]) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def get_triage_care_levels_by_id(self, doc_id: str) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def get_triage_assessment_by_disposition(
        self, doc_id: str, disposition: str
    ) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def get_care_advice_by_ids(
        self, doc_id: str, care_advice_ids: List[int]
    ) -> str:
        pass

    @abstractmethod
    async def get_care_advice_by_question_id(
        self, doc_id: str, question_id: str
    ) -> str:
        pass

    @abstractmethod
    async def get_triage_assessment_by_doc_id(self, doc_id: str) -> str:
        pass

    @abstractmethod
    async def get_grouped_triage_assessment_by_doc_id(self, doc_id: str) -> str:
        pass

    @abstractmethod
    async def get_triage_assessment_by_doc_title(self, doc_title: str) -> str:
        pass


class OpenSearchIndexService(IndexService):
    def __init__(self, embedding_service):
        self.client = self._create_opensearch_client()
        self.embedding_service = embedding_service
        self.embedding_dim = config.get("EMBEDDING_DIM", 384)
        self.embedding_max_context = config.get("EMBEDDING_MAX_CONTEXT", 384)
        self.index_name = "medical_protocols"

    def _create_opensearch_client(self) -> AsyncOpenSearch:
        host = config.get("OPENSEARCH_HOST", "localhost")
        port = config.get("OPENSEARCH_PORT", 9200)
        username = config.get("OPENSEARCH_USERNAME", "")
        password = config.get("OPENSEARCH_PASSWORD", "")

        http_auth = None
        if username and password:
            http_auth = (username, password)

        return AsyncOpenSearch(
            hosts=[{"host": host, "port": port}],
            http_auth=http_auth,
            use_ssl=False,
            verify_certs=False,
            connection_class=AIOHttpConnection,
        )

    def _truncate_text_for_embedding(self, text: str) -> str:
        max_length = self.embedding_max_context

        tokens = self.embedding_service.get_tokens_from_string(text)
        if len(tokens) <= max_length - 2:  # Account for special tokens
            return text

        truncated_tokens = tokens[: max_length - 2]
        return self.embedding_service.get_string_from_tokens(truncated_tokens)

    async def _generate_embedding(self, text: str) -> List[float]:
        truncated_text = self._truncate_text_for_embedding(text)
        embedding = await self.embedding_service.embed_text(truncated_text)
        return embedding.data[0].embedding

    def _generate_document_id(self, document: Dict[str, Any]) -> str:
        title = document.get("title", "")
        classification = document.get("classification", "")
        content_hash = hashlib.md5(
            json.dumps(document, sort_keys=True).encode()
        ).hexdigest()[:8]
        return f"{title.lower().replace(' ', '_')}_{classification}_{content_hash}"

    async def create_index_if_not_exists(self) -> bool:
        if await self.client.indices.exists(index=self.index_name):
            logger.info(f"Index {self.index_name} already exists")
            return True

        index_mapping = {
            "settings": {"index.knn": True},
            "mappings": {
                "properties": {
                    # Indexed and searchable fields
                    "title": {"type": "keyword"},
                    "classification": {"type": "keyword"},
                    "gender": {"type": "keyword"},
                    "definition": {"type": "text"},
                    "background": {"type": "text"},
                    "background_embedding": {
                        "type": "knn_vector",
                        "dimension": self.embedding_dim,
                        "space_type": "l2",
                    },
                    "search_keywords": {"type": "keyword"},
                    "search_keywords_text": {"type": "text"},
                    # Nested field for triage assessments: only 'disposition' is indexed for filtering
                    "triage_assessment": {
                        "type": "nested",
                        "properties": {
                            "disposition": {"type": "keyword"},
                            "disposition_mapped": {"type": "keyword"},
                            "symptom": {"type": "text", "index": False},
                            "ro": {"type": "text", "index": False},
                            "reason": {"type": "text", "index": False},
                            "first_aid": {"type": "text", "index": False},
                            "ca": {"type": "integer", "index": False},
                        },
                    },
                    # Non-indexed but retrievable fields
                    "triage_care_levels": {"type": "keyword", "index": False},
                    "triage_care_levels_mapped": {"type": "keyword", "index": False},
                    "triage_assessment_grouped": {"type": "object", "enabled": False},
                    "question_care_advice_mapping": {
                        "type": "object",
                        "enabled": False,
                    },
                    "smag": {"type": "object", "enabled": False},
                    "ca": {"type": "object", "enabled": False},
                }
            },
        }

        try:
            response = await self.client.indices.create(
                index=self.index_name, body=index_mapping
            )
            logger.info(f"Created index {self.index_name}: {response}")
            return True
        except Exception as e:
            logger.error(f"Failed to create index {self.index_name}: {e}")
            return False

    async def index_document(self, document: Dict[str, Any]) -> Dict[str, Any]:
        try:
            # Create index if it doesn't exist
            await self.create_index_if_not_exists()

            # Generate document ID
            doc_id = self._generate_document_id(document)

            # Prepare document for indexing
            indexed_doc = {
                "title": document.get("title", ""),
                "classification": document.get("classification", ""),
                "gender": document.get("gender", ""),
                "definition": document.get("definition", ""),
                "background": document.get("background", ""),
                "triage_assessment": document.get("triage_assessment", []),
                "triage_care_levels": document.get("triage_care_levels", []),
                "triage_care_levels_mapped": document.get(
                    "triage_care_levels_mapped", []
                ),
                "triage_assessment_grouped": document.get(
                    "triage_assessment_grouped", []
                ),
                "question_care_advice_mapping": document.get(
                    "question_care_advice_mapping", []
                ),
                "search_keywords": document.get("search_keywords", []),
                "search_keywords_text": " ".join(document.get("search_keywords", [])),
                "smag": document.get("smag", {}),
                "ca": document.get("ca", {}),
            }

            # Generate embedding for background text if present
            background_text = document.get("background", "")
            if background_text:
                indexed_doc["background_embedding"] = await self._generate_embedding(
                    background_text
                )

            # Index the document
            response = await self.client.index(
                index=self.index_name, id=doc_id, body=indexed_doc
            )

            logger.info(f"Successfully indexed document: {doc_id}")
            return {"success": True, "document_id": doc_id, "response": response}

        except Exception as e:
            logger.error(f"Failed to index document: {e}")
            return {"success": False, "error": str(e)}

    async def search_documents(
        self,
        classification: str,
        gender: str,
        keywords: List[str],
        query: str,
        top_k: int,
    ) -> str:
        try:
            gender_terms = []
            if gender == "male":
                gender_terms = ["male", "neutral"]
            elif gender == "female":
                gender_terms = ["female", "neutral"]
            elif gender == "neutral":
                gender_terms = ["neutral"]

            gender_clause = {
                "bool": {
                    "should": [{"term": {"gender": t}} for t in gender_terms],
                    "minimum_should_match": 1,
                }
            }

            # Base filters that always apply
            filters = [
                {"term": {"classification": classification}},
                gender_clause,
            ]

            # Add keyword filter as hard requirement
            if keywords:
                keyword_filter = {
                    "bool": {
                        "should": [
                            {"term": {"search_keywords": kw}} for kw in keywords
                        ],
                        "minimum_should_match": 1,  # At least one keyword must match
                    }
                }
                filters.append(keyword_filter)

            # Generate embedding for semantic search
            query_vec = await self._generate_embedding(query)

            # Single k-NN search with all filters applied
            knn_body = {
                "query": {
                    "bool": {
                        "filter": filters,
                        "must": {
                            "knn": {
                                "background_embedding": {
                                    "vector": query_vec,
                                    "k": top_k,
                                }
                            }
                        },
                    }
                },
                "size": top_k,
            }

            resp = await self.client.search(index=self.index_name, body=knn_body)
            hits = resp["hits"]["hits"]

            # Format results
            results = []
            for hit in hits:
                doc_id = hit["_id"]
                source = hit.get("_source", {})
                results.append(
                    {
                        "id": doc_id,
                        "title": source.get("title"),
                        "description": source.get("definition"),
                        "score": hit.get("_score"),
                        "type": "semantic",
                    }
                )

            return json.dumps(
                {"success": True, "documents": results, "total_hits": len(results)}
            )

        except Exception as e:
            logger.error(f"Search failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def get_documents_by_ids(self, ids: List[str]) -> Dict[str, Any]:
        try:
            resp = await self.client.mget(body={"ids": ids}, index=self.index_name)
            return {"success": True, "documents": resp.get("docs", [])}
        except Exception as e:
            logger.error(f"get_documents_by_ids failed: {e}")
            return {"success": False, "error": str(e)}

    async def get_documents_by_titles(self, titles: List[str]) -> Dict[str, Any]:
        try:
            query_body = {"query": {"terms": {"title": titles}}, "size": len(titles)}
            resp = await self.client.search(index=self.index_name, body=query_body)
            return {
                "success": True,
                "documents": resp.get("hits", {}).get("hits", []),
                "total_hits": resp.get("hits", {}).get("total", {}).get("value", 0),
            }
        except Exception as e:
            logger.error(f"get_documents_by_titles failed: {e}")
            return {"success": False, "error": str(e)}

    async def get_triage_care_levels_by_id(self, doc_id: str) -> str:
        try:
            resp = await self.client.get(index=self.index_name, id=doc_id)
            source = resp.get("_source", {})
            return json.dumps(
                {
                    "success": True,
                    "triage_care_levels": source.get("triage_care_levels_mapped", []),
                }
            )
        except Exception as e:
            logger.error(f"get_triage_care_levels_by_id failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def get_triage_assessment_by_disposition(
        self, doc_id: str, disposition: str
    ) -> str:
        try:
            resp = await self.client.get(index=self.index_name, id=doc_id)
            source = resp.get("_source", {})
            assessments = source.get("triage_assessment", [])

            # Filter assessments by disposition
            filtered = [
                {
                    "symptom": a.get("symptom"),
                    "rule_out": a.get("ro"),
                    "care_advice": a.get("ca"),
                }
                for a in assessments
                if a.get("disposition_mapped") == disposition
            ]

            return json.dumps(
                {
                    "success": True,
                    "disposition": disposition,
                    "triage_questions": filtered,
                }
            )
        except Exception as e:
            logger.error(f"get_triage_assessment_by_disposition failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def get_care_advice_by_ids(
        self, doc_id: str, care_advice_ids: List[int]
    ) -> str:
        try:
            resp = await self.client.get(index=self.index_name, id=doc_id)
            source = resp.get("_source", {})
            ca_map = source.get("ca", {})

            care_advice_list = []
            for ca_id in care_advice_ids:
                # TODO: Clean up this logic: it is meant to skip care ids in 40s range because they list ST disposition, not CCF disposition and this confuses the LLM
                if 40 <= ca_id <= 49:
                    continue
                advice_text = ca_map.get(str(ca_id))
                if advice_text:
                    care_advice_list.append({"id": str(ca_id), "advice": advice_text})

            return json.dumps({"success": True, "care_advice": care_advice_list})
        except Exception as e:
            logger.error(f"get_care_advice_by_ids failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def get_care_advice_by_question_id(
        self, doc_id: str, question_id: str
    ) -> str:
        """Get care advice for a specific question ID by looking up the question_care_advice_mapping"""
        try:
            resp = await self.client.get(index=self.index_name, id=doc_id)
            source = resp.get("_source", {})
            question_mapping = source.get("question_care_advice_mapping", {})

            # Get the care advice IDs for this question ID
            care_advice_ids = question_mapping.get(str(question_id))
            if care_advice_ids is None:
                return json.dumps(
                    {
                        "success": False,
                        "error": f"Question ID '{question_id}' not found in question_care_advice_mapping",
                    }
                )

            # Convert to list of integers if needed
            if isinstance(care_advice_ids, list):
                care_advice_ids = [int(ca_id) for ca_id in care_advice_ids]
            else:
                return json.dumps(
                    {
                        "success": False,
                        "error": f"Invalid care advice mapping format for question ID '{question_id}'",
                    }
                )

            # Use the existing get_care_advice_by_ids method
            return await self.get_care_advice_by_ids(doc_id, care_advice_ids)

        except Exception as e:
            logger.error(f"get_care_advice_by_question_id failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def get_grouped_triage_assessment_by_doc_id(self, doc_id: str) -> str:
        """Get triage_assessment field from document by document ID"""
        try:
            resp = await self.client.get(index=self.index_name, id=doc_id)
            source = resp.get("_source", {})
            assessments = source.get("triage_assessment_grouped", [])

            return json.dumps(
                {
                    "success": True,
                    "doc_id": doc_id,
                    "triage_assessment": assessments,
                }
            )
        except Exception as e:
            logger.error(f"get_triage_assessment_by_doc_id failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def get_triage_assessment_by_doc_id(self, doc_id: str) -> str:
        """Get triage_assessment field from document by document ID"""
        try:
            resp = await self.client.get(index=self.index_name, id=doc_id)
            source = resp.get("_source", {})
            assessments = source.get("triage_assessment", [])

            # Filter and format assessments as specified
            filtered = [
                {
                    "symptom": a.get("symptom"),
                    "rule_out": a.get("ro"),
                    "care_advice": a.get("ca"),
                    "disposition": a.get("disposition_mapped"),
                }
                for a in assessments
            ]

            return json.dumps(
                {
                    "success": True,
                    "doc_id": doc_id,
                    "triage_assessment": filtered,
                }
            )
        except Exception as e:
            logger.error(f"get_triage_assessment_by_doc_id failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def get_triage_assessment_by_doc_title(self, doc_title: str) -> str:
        """Get triage_assessment field from document by document title"""
        try:
            # Search for document by title
            query_body = {"query": {"term": {"title": doc_title}}, "size": 1}
            resp = await self.client.search(index=self.index_name, body=query_body)
            hits = resp.get("hits", {}).get("hits", [])

            if not hits:
                return json.dumps(
                    {
                        "success": False,
                        "error": f"Document with title '{doc_title}' not found",
                    }
                )

            source = hits[0].get("_source", {})
            doc_id = hits[0].get("_id")
            assessments = source.get("triage_assessment", [])

            # Filter and format assessments as specified
            filtered = [
                {
                    "symptom": a.get("symptom"),
                    "rule_out": a.get("ro"),
                    "care_advice": a.get("ca"),
                    "disposition": a.get("disposition_mapped"),
                }
                for a in assessments
            ]

            return json.dumps(
                {
                    "success": True,
                    "doc_id": doc_id,
                    "doc_title": doc_title,
                    "triage_assessment": filtered,
                }
            )
        except Exception as e:
            logger.error(f"get_triage_assessment_by_doc_title failed: {e}")
            return json.dumps({"success": False, "error": str(e)})


class AzureCognitiveSearchIndexService(IndexService):
    def __init__(self, embedding_service):
        self.embedding_service = embedding_service
        self.embedding_dim = config.get("EMBEDDING_DIM", 1536)
        self.embedding_max_context = config.get("EMBEDDING_MAX_CONTEXT", 8191)
        self.index_name = config.get("AZURE_SEARCH_INDEX_NAME", "medical_protocols")

        # Azure Cognitive Search configuration
        self.endpoint = config["AZURE_SEARCH_ENDPOINT"]
        self.credential = get_credential()

        # Initialize clients
        self.search_client = SearchClient(
            endpoint=self.endpoint,
            index_name=self.index_name,
            credential=self.credential,
        )
        self.index_client = SearchIndexClient(
            endpoint=self.endpoint, credential=self.credential
        )

    def _truncate_text_for_embedding(self, text: str) -> str:
        max_length = self.embedding_max_context
        tokens = self.embedding_service.get_tokens_from_string(text)
        if len(tokens) <= max_length - 2:
            return text
        truncated_tokens = tokens[: max_length - 2]
        return self.embedding_service.get_string_from_tokens(truncated_tokens)

    async def _generate_embedding(self, text: str) -> List[float]:
        truncated_text = self._truncate_text_for_embedding(text)
        embedding = await self.embedding_service.embed_text(truncated_text)
        return embedding.data[0].embedding

    def _generate_document_id(self, document: Dict[str, Any]) -> str:
        title = document.get("title", "")
        classification = document.get("classification", "")
        content_hash = hashlib.md5(
            json.dumps(document, sort_keys=True).encode()
        ).hexdigest()[:8]
        return f"{title.lower().replace(' ', '_')}_{classification}_{content_hash}"

    async def create_index_if_not_exists(self) -> bool:
        try:
            # Check if index exists
            try:
                await self.index_client.get_index(self.index_name)
                logger.info(f"Index {self.index_name} already exists")
                return True
            except Exception:
                # Index doesn't exist, create it
                pass

            # Define the index schema
            fields = [
                SimpleField(name="id", type=SearchFieldDataType.String, key=True),
                SearchableField(
                    name="title",
                    type=SearchFieldDataType.String,
                    filterable=True,
                    facetable=True,
                ),
                SimpleField(
                    name="classification",
                    type=SearchFieldDataType.String,
                    filterable=True,
                    facetable=True,
                ),
                SimpleField(
                    name="gender",
                    type=SearchFieldDataType.String,
                    filterable=True,
                    facetable=True,
                ),
                SearchableField(name="definition", type=SearchFieldDataType.String),
                SearchableField(name="background", type=SearchFieldDataType.String),
                SearchField(
                    name="background_embedding",
                    type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                    searchable=True,
                    vector_search_dimensions=self.embedding_dim,
                    vector_search_profile_name="default",
                ),
                SimpleField(
                    name="search_keywords",
                    type=SearchFieldDataType.Collection(SearchFieldDataType.String),
                    filterable=True,
                    facetable=True,
                ),
                SearchableField(
                    name="search_keywords_text", type=SearchFieldDataType.String
                ),
                SimpleField(
                    name="triage_assessment",
                    type=SearchFieldDataType.String,
                    retrievable=True,
                ),
                SimpleField(
                    name="triage_care_levels",
                    type=SearchFieldDataType.Collection(SearchFieldDataType.String),
                    retrievable=True,
                ),
                SimpleField(
                    name="triage_care_levels_mapped",
                    type=SearchFieldDataType.Collection(SearchFieldDataType.String),
                    retrievable=True,
                ),
                SimpleField(
                    name="triage_assessment_grouped",
                    type=SearchFieldDataType.String,
                    retrievable=True,
                ),
                SimpleField(
                    name="question_care_advice_mapping",
                    type=SearchFieldDataType.String,
                    retrievable=True,
                ),
                SimpleField(
                    name="smag", type=SearchFieldDataType.String, retrievable=True
                ),
                SimpleField(
                    name="ca", type=SearchFieldDataType.String, retrievable=True
                ),
            ]

            # Configure vector search
            vector_search = VectorSearch(
                profiles=[
                    VectorSearchProfile(
                        name="default", algorithm_configuration_name="default"
                    )
                ],
                algorithms=[HnswAlgorithmConfiguration(name="default")],
            )

            # Create the index
            index = SearchIndex(
                name=self.index_name, fields=fields, vector_search=vector_search
            )

            await self.index_client.create_index(index)
            logger.info(f"Created Azure Cognitive Search index: {self.index_name}")
            return True

        except Exception as e:
            logger.error(f"Failed to create index {self.index_name}: {e}")
            return False

    async def index_document(self, document: Dict[str, Any]) -> Dict[str, Any]:
        try:
            await self.create_index_if_not_exists()

            doc_id = self._generate_document_id(document)

            # Prepare document for Azure Cognitive Search
            indexed_doc = {
                "id": doc_id,
                "title": document.get("title", ""),
                "classification": document.get("classification", ""),
                "gender": document.get("gender", ""),
                "definition": document.get("definition", ""),
                "background": document.get("background", ""),
                "search_keywords": document.get("search_keywords", []),
                "search_keywords_text": " ".join(document.get("search_keywords", [])),
                "triage_assessment": json.dumps(document.get("triage_assessment", [])),
                "triage_care_levels": document.get("triage_care_levels", []),
                "triage_care_levels_mapped": document.get(
                    "triage_care_levels_mapped", []
                ),
                "triage_assessment_grouped": json.dumps(
                    document.get("triage_assessment_grouped", [])
                ),
                "question_care_advice_mapping": json.dumps(
                    document.get("question_care_advice_mapping", {})
                ),
                "smag": json.dumps(document.get("smag", {})),
                "ca": json.dumps(document.get("ca", {})),
            }

            # Generate embedding for background text
            background_text = document.get("background", "")
            if background_text:
                indexed_doc["background_embedding"] = await self._generate_embedding(
                    background_text
                )

            # Upload document
            await self.search_client.upload_documents([indexed_doc])

            logger.info(f"Successfully indexed document: {doc_id}")
            return {
                "success": True,
                "document_id": doc_id,
                "result": "Document uploaded successfully",
            }

        except Exception as e:
            logger.error(f"Failed to index document: {e}")
            return {"success": False, "error": str(e)}

    async def search_documents(
        self,
        classification: str,
        gender: str,
        keywords: List[str],
        query: str,
        top_k: int,
    ) -> str:
        try:
            # Build filters
            filter_conditions = [f"classification eq '{classification}'"]

            # Gender filtering
            if gender == "male":
                filter_conditions.append("(gender eq 'male' or gender eq 'neutral')")
            elif gender == "female":
                filter_conditions.append("(gender eq 'female' or gender eq 'neutral')")
            elif gender == "neutral":
                filter_conditions.append("gender eq 'neutral'")

            # Keywords filtering
            if keywords:
                keyword_conditions = " or ".join(
                    [f"search_keywords/any(k: k eq '{kw}')" for kw in keywords]
                )
                filter_conditions.append(f"({keyword_conditions})")

            filter_expression = " and ".join(filter_conditions)

            # Generate embedding for vector search
            query_vector = await self._generate_embedding(query)
            # Perform vector search with filters
            vector_query = VectorizedQuery(
                vector=query_vector,
                k_nearest_neighbors=top_k,
                fields="background_embedding",
            )

            results = await self.search_client.search(
                search_text=None,
                vector_queries=[vector_query],
                filter=filter_expression,
                top=top_k,
                select=["id", "title", "definition"],
            )

            # Format results
            documents = []
            async for result in results:
                documents.append(
                    {
                        "id": result["id"],
                        "title": result["title"],
                        "description": result.get("definition", ""),
                        "score": result.get("@search.score", 0),
                        "type": "semantic",
                    }
                )

            return json.dumps(
                {"success": True, "documents": documents, "total_hits": len(documents)}
            )

        except Exception as e:
            logger.error(f"Search failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def get_documents_by_ids(self, ids: List[str]) -> Dict[str, Any]:
        try:
            results = await self.search_client.get_documents(keys=ids)
            documents = [doc async for doc in results]
            return {"success": True, "documents": documents}
        except Exception as e:
            logger.error(f"get_documents_by_ids failed: {e}")
            return {"success": False, "error": str(e)}

    async def get_documents_by_titles(self, titles: List[str]) -> Dict[str, Any]:
        try:
            title_conditions = " or ".join([f"title eq '{title}'" for title in titles])

            results = await self.search_client.search(
                search_text=None, filter=title_conditions, top=len(titles)
            )

            documents = [result async for result in results]
            return {
                "success": True,
                "documents": documents,
                "total_hits": len(documents),
            }
        except Exception as e:
            logger.error(f"get_documents_by_titles failed: {e}")
            return {"success": False, "error": str(e)}

    async def get_triage_care_levels_by_id(self, doc_id: str) -> str:
        try:
            result = await self.search_client.get_document(key=doc_id)
            triage_care_levels = result.get("triage_care_levels_mapped", [])
            return json.dumps(
                {"success": True, "triage_care_levels": triage_care_levels}
            )
        except Exception as e:
            logger.error(f"get_triage_care_levels_by_id failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def get_triage_assessment_by_disposition(
        self, doc_id: str, disposition: str
    ) -> str:
        try:
            result = await self.search_client.get_document(key=doc_id)
            assessments = json.loads(result.get("triage_assessment", "[]"))

            filtered = [
                {
                    "symptom": a.get("symptom"),
                    "rule_out": a.get("ro"),
                    "care_advice": a.get("ca"),
                }
                for a in assessments
                if a.get("disposition_mapped") == disposition
            ]

            return json.dumps(
                {
                    "success": True,
                    "disposition": disposition,
                    "triage_questions": filtered,
                }
            )
        except Exception as e:
            logger.error(f"get_triage_assessment_by_disposition failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def get_care_advice_by_ids(
        self, doc_id: str, care_advice_ids: List[int]
    ) -> str:
        try:
            result = await self.search_client.get_document(key=doc_id)
            ca_map = json.loads(result.get("ca", "{}"))

            care_advice_list = []
            for ca_id in care_advice_ids:
                if 40 <= ca_id <= 49:
                    continue
                advice_text = ca_map.get(str(ca_id))
                if advice_text:
                    care_advice_list.append({"id": str(ca_id), "advice": advice_text})

            return json.dumps({"success": True, "care_advice": care_advice_list})
        except Exception as e:
            logger.error(f"get_care_advice_by_ids failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def get_care_advice_by_question_id(
        self, doc_id: str, question_id: str
    ) -> str:
        try:
            result = await self.search_client.get_document(key=doc_id)
            question_mapping = json.loads(
                result.get("question_care_advice_mapping", "{}")
            )

            care_advice_ids = question_mapping.get(str(question_id))
            if care_advice_ids is None:
                return json.dumps(
                    {
                        "success": False,
                        "error": f"Question ID '{question_id}' not found in question_care_advice_mapping",
                    }
                )

            if isinstance(care_advice_ids, list):
                care_advice_ids = [int(ca_id) for ca_id in care_advice_ids]
            else:
                return json.dumps(
                    {
                        "success": False,
                        "error": f"Invalid care advice mapping format for question ID '{question_id}'",
                    }
                )

            return await self.get_care_advice_by_ids(doc_id, care_advice_ids)

        except Exception as e:
            logger.error(f"get_care_advice_by_question_id failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def get_grouped_triage_assessment_by_doc_id(self, doc_id: str) -> str:
        """Get triage_assessment_grouped field from document by document ID"""
        try:
            result = await self.search_client.get_document(key=doc_id)
            assessments = json.loads(result.get("triage_assessment_grouped", "[]"))

            return json.dumps(
                {
                    "success": True,
                    "doc_id": doc_id,
                    "triage_assessment": assessments,
                }
            )
        except Exception as e:
            logger.error(f"get_grouped_triage_assessment_by_doc_id failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def get_triage_assessment_by_doc_id(self, doc_id: str) -> str:
        try:
            result = await self.search_client.get_document(key=doc_id)
            assessments = json.loads(result.get("triage_assessment", "[]"))

            filtered = [
                {
                    "symptom": a.get("symptom"),
                    "rule_out": a.get("ro"),
                    "care_advice": a.get("ca"),
                    "disposition": a.get("disposition_mapped"),
                }
                for a in assessments
            ]

            return json.dumps(
                {"success": True, "doc_id": doc_id, "triage_assessment": filtered}
            )
        except Exception as e:
            logger.error(f"get_triage_assessment_by_doc_id failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def get_triage_assessment_by_doc_title(self, doc_title: str) -> str:
        try:
            results = await self.search_client.search(
                search_text=None, filter=f"title eq '{doc_title}'", top=1
            )

            documents = [result async for result in results]
            if not documents:
                return json.dumps(
                    {
                        "success": False,
                        "error": f"Document with title '{doc_title}' not found",
                    }
                )

            doc = documents[0]
            doc_id = doc["id"]
            assessments = json.loads(doc.get("triage_assessment", "[]"))

            filtered = [
                {
                    "symptom": a.get("symptom"),
                    "rule_out": a.get("ro"),
                    "care_advice": a.get("ca"),
                    "disposition": a.get("disposition_mapped"),
                }
                for a in assessments
            ]

            return json.dumps(
                {
                    "success": True,
                    "doc_id": doc_id,
                    "doc_title": doc_title,
                    "triage_assessment": filtered,
                }
            )
        except Exception as e:
            logger.error(f"get_triage_assessment_by_doc_title failed: {e}")
            return json.dumps({"success": False, "error": str(e)})

    async def close(self):
        """Close Azure clients"""
        await self.search_client.close()
        await self.index_client.close()


def get_index_service() -> IndexService:
    from digital_frontdoor.services import get_embedding_service

    embedding_service = get_embedding_service()

    # Use Azure Cognitive Search if endpoint is configured, otherwise fallback to OpenSearch
    if config.get("AZURE_SEARCH_ENDPOINT"):
        return AzureCognitiveSearchIndexService(embedding_service)
    else:
        return OpenSearchIndexService(embedding_service)


async def main():
    parser = argparse.ArgumentParser(
        description="Index a JSON document into OpenSearch"
    )
    parser.add_argument(
        "--json_path",
        required=True,
        help="Path to the JSON file representing the document to index",
    )
    args = parser.parse_args()

    # Read document
    try:
        with open(args.json_path, "r", encoding="utf-8") as f:
            document = json.load(f)
    except Exception as e:
        logger.error(f"Failed to read JSON file at {args.json_path}: {e}")
        exit(1)

    # Initialize service and index document
    service = get_index_service()

    try:
        # Example: Index a document
        result = await service.index_document(document)
        print("Index result:", json.dumps(result, indent=2))

    finally:
        # Properly close the async client based on service type
        if hasattr(service, "close"):
            await service.close()
        elif hasattr(service, "client"):
            await service.client.close()


if __name__ == "__main__":
    asyncio.run(main())
