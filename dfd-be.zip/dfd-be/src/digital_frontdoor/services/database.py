from abc import ABC, abstractmethod
from typing import Generator, AsyncGenerator
from digital_frontdoor.config import (
    get_config,
    get_postgres_url_without_password,
    get_azure_postgres_password,
)
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
import logging

logger = logging.getLogger(__name__)

config = get_config()


class DatabaseService(ABC):
    @abstractmethod
    async def get_async_db(self) -> AsyncGenerator[AsyncSession, None]:
        pass


class MySQLDatabaseService(DatabaseService):
    def __init__(self):
        mysql_url = config["MYSQL_DATABASE_URL"]
        db = config["MYSQL_DATABASE_NAME"]

        # Async engine with aiomysql
        async_url = f"{mysql_url}{db}"

        self.async_engine = create_async_engine(
            async_url, pool_pre_ping=True, pool_recycle=3600
        )
        self.AsyncSessionLocal = async_sessionmaker(
            autocommit=False, autoflush=False, bind=self.async_engine
        )

    async def get_async_db(self) -> AsyncGenerator[AsyncSession, None]:
        try:
            async with self.AsyncSessionLocal() as db:
                yield db
        except Exception as e:
            logger.error(f"Error getting async database: {e}")
            raise e


class PostgreSQLDatabaseService(DatabaseService):
    def __init__(self):
        # Use URL without password and pass token via connect_args callable
        postgres_url = get_postgres_url_without_password()

        self.async_engine = create_async_engine(
            postgres_url,
            pool_pre_ping=True,
            pool_recycle=1800,  # Recycle connections every 30 minutes to refresh tokens
            echo=False,
            pool_size=5,  # Limit pool size for Azure
            max_overflow=0,  # No overflow connections
            connect_args={
                "password": get_azure_postgres_password,  # Callable for fresh tokens
                "server_settings": {
                    "jit": "off"  # Disable JIT for better compatibility
                },
            },
        )
        self.AsyncSessionLocal = async_sessionmaker(
            autocommit=False, autoflush=False, bind=self.async_engine
        )

    async def get_async_db(self) -> AsyncGenerator[AsyncSession, None]:
        try:
            async with self.AsyncSessionLocal() as db:
                yield db
        except Exception as e:
            logger.error(f"Error getting async PostgreSQL database: {e}")
            raise e
