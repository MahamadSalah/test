from dotenv import load_dotenv, find_dotenv

load_dotenv(find_dotenv())

import mlflow

mlflow.openai.autolog()

from tenacity import (
    retry,
    stop_after_attempt,
    wait_random_exponential,
)
import asyncio
from abc import ABC, abstractmethod
from typing import List, Dict
from digital_frontdoor.config import get_config, get_credential
import json
import uuid
import logging
import os
import digital_frontdoor.schemas as schemas
from agents import (
    Agent,
    Runner,
    trace,
    gen_trace_id,
    handoff,
    RunConfig,
    InputGuardrail,
    GuardrailFunctionOutput,
    OutputGuardrailTripwireTriggered,
    InputGuardrailTripwireTriggered,
    input_guardrail,
    set_tracing_export_api_key,
    enable_verbose_stdout_logging,
    OpenAIChatCompletionsModel,
    set_default_openai_client,
    set_default_openai_api,
    function_tool,
    set_trace_processors,
)
from agents.mcp import MCPServerStreamableHttp, create_static_tool_filter
from agents.extensions import handoff_filters
from openai import AsyncAzureOpenAI
from openai.types.shared import Reasoning
from azure.identity import get_bearer_token_provider

from openai.types.responses import ResponseTextDeltaEvent

from agents.model_settings import ModelSettings

from digital_frontdoor.services import PromptFactory


config = get_config()

token_provider = get_bearer_token_provider(
    get_credential(), "https://cognitiveservices.azure.com/.default"
)

set_default_openai_client(
    AsyncAzureOpenAI(
        api_version=config.get("AZURE_API_VERSION", "2024-12-01-preview"),
        azure_endpoint=config.get("AZURE_API_BASE", ""),
        azure_ad_token_provider=token_provider,
    )
)
set_default_openai_api("chat_completions")

logger = logging.getLogger(__name__)


class AgentService(ABC):
    @abstractmethod
    async def run_input_guardrail_agent(
        self,
        model,
        input_data,
        prompt,
    ):
        pass

    @abstractmethod
    async def run_orchestrator_with_trace(
        self,
        orchestrator_model,
        prompts,
        conversation_list,
    ):
        pass


class AgentServiceImpl(AgentService):
    @retry(wait=wait_random_exponential(min=1, max=30), stop=stop_after_attempt(3))
    async def run_input_guardrail_agent(
        self,
        model,
        input_data,
        prompt,
    ):

        model_settings = (
            ModelSettings(
                temperature=config.get("GUARDRAIL_TEMPERATURE", 0.1),
            )
            if "gpt-5" not in model
            else ModelSettings()
        )

        self.guardrail_agent = Agent(
            name="Guardrail Agent",
            instructions=prompt,
            output_type=schemas.GuardrailOutput,
            model=model,
            model_settings=model_settings,
        )

        result = await Runner.run(self.guardrail_agent, input_data)
        final_output = result.final_output_as(schemas.GuardrailOutput)
        tripwire_triggered = not final_output.is_within_scope

        # Extract token usage information safely
        usage = getattr(result.context_wrapper, "usage", None)
        token_usage = (
            {
                "input_tokens": getattr(usage, "input_tokens", 0),
                "cached_tokens": getattr(
                    getattr(usage, "input_tokens_details", None), "cached_tokens", 0
                ),
                "output_tokens": getattr(usage, "output_tokens", 0),
                "reasoning_tokens": getattr(
                    getattr(usage, "output_tokens_details", None), "reasoning_tokens", 0
                ),
                "requests": getattr(usage, "requests", 1),
            }
            if usage
            else {
                "input_tokens": 0,
                "cached_tokens": 0,
                "output_tokens": 0,
                "reasoning_tokens": 0,
                "requests": 1,
            }
        )

        return (
            GuardrailFunctionOutput(
                output_info=final_output,
                tripwire_triggered=tripwire_triggered,
            ),
            token_usage,
        )

    @retry(wait=wait_random_exponential(min=1, max=30), stop=stop_after_attempt(3))
    async def run_orchestrator(
        self,
        orchestrator_model,
        prompts,
        conversation_list,
    ):

        orchestrator = Agent(
            name="Orchestrator Agent",
            instructions=prompts.orchestrator,
            model_settings=ModelSettings(
                temperature=config.get("ORCHESTRATOR_TEMPERATURE", 0.1),
            ),
            model=orchestrator_model,
            output_type=schemas.AssistantMessageWithTermination,
        )

        result = await Runner.run(orchestrator, conversation_list)

        # Extract token usage information safely
        usage = getattr(result.context_wrapper, "usage", None)
        token_usage = (
            {
                "input_tokens": getattr(usage, "input_tokens", 0),
                "cached_tokens": getattr(
                    getattr(usage, "input_tokens_details", None), "cached_tokens", 0
                ),
                "output_tokens": getattr(usage, "output_tokens", 0),
                "reasoning_tokens": getattr(
                    getattr(usage, "output_tokens_details", None), "reasoning_tokens", 0
                ),
                "requests": getattr(usage, "requests", 1),
            }
            if usage
            else {
                "input_tokens": 0,
                "cached_tokens": 0,
                "output_tokens": 0,
                "reasoning_tokens": 0,
                "requests": 1,
            }
        )

        return result, token_usage

    async def run_orchestrator_with_trace(
        self,
        orchestrator_model,
        prompts,
        conversation_list,
    ):
        """
        Run orchestrator with trace context management.
        Returns tuple of (runner_result, trace_id) for external use.
        """
        DATABRICKS_HOST = os.environ.get("DATABRICKS_HOST")
        EXP_ID = os.environ.get("MLFLOW_EXPERIMENT_ID")

        with mlflow.start_span(name="Main Trace", span_type="AGENT") as span:
            span.set_inputs(
                {
                    "orchestrator_model": orchestrator_model,
                    "prompts": prompts,
                    "conversation_list": conversation_list,
                }
            )
            runner_result, token_usage = await self.run_orchestrator(
                orchestrator_model=orchestrator_model,
                prompts=prompts,
                conversation_list=conversation_list,
            )
            span.set_outputs({"output": runner_result.final_output})

            trace_url = f"{DATABRICKS_HOST}/ml/experiments/{EXP_ID}/traces?o=8327051358258325&selectedEvaluationId={span.request_id}"
        print(f"Trace URL: {trace_url}")
        return runner_result, trace_url, token_usage
